const subjects = [
  {
    id: 'math-aa-hl', name: 'Mathematics AA', level: 'HL', icon: '∫', color: 'blue',
    // Added Integration to highlight integration techniques and differentiate from general calculus
    topics: ['Number & Algebra', 'Functions', 'Geometry & Trigonometry', 'Calculus', 'Differentiation', 'Integration', 'Sequences & Series', 'Vectors', 'Complex numbers', 'Probability', 'Statistics'],
    description: 'Concept-first HL revision with worked reasoning, markscheme wording, and IA support.'
  },
  {
    id: 'physics-hl', name: 'Physics', level: 'HL', icon: 'λ', color: 'green',
    // Added Modern physics to cover photoelectric effect and other quantum phenomena
    topics: ['Mechanics', 'Fields', 'Waves', 'Electricity', 'Thermal physics', 'Modern physics', 'Quantum', 'Oscillations & SHM', 'Nuclear & particle physics', 'Data analysis'],
    description: 'Formula use, explanation practice, uncertainty, and Paper 2 problem solving.'
  },
  {
    id: 'cs-hl', name: 'Computer Science', level: 'HL', icon: '{}', color: 'purple',
    // Added Linked lists and Searching algorithms for more detailed algorithmic practice
    topics: ['ADT', 'Linked lists', 'OOP', 'Databases', 'Networks', 'Algorithms', 'Searching algorithms', 'Complexity', 'Recursion', 'Web apps', 'Programming paradigms'],
    description: 'Pseudocode, Paper 2 structures, IA criteria, algorithms, and web project explanations.'
  },
  {
    id: 'english-a', name: 'English A Literature', level: 'SL/HL', icon: '¶', color: 'orange',
    // Added Rhetoric to explore persuasive techniques such as rhetorical questions
    topics: ['Paper 1', 'Paper 2', 'IO', 'Rhetoric', 'Authorial choices', 'Thesis writing', 'Motifs', 'Narrative voice'],
    description: 'Analytical paragraph building, global issue work, and oral practice.'
  },
  {
    id: 'tok', name: 'Theory of Knowledge', level: 'Core', icon: '?', color: 'red',
    // Added Knowledge frameworks and Ways of knowing to align with latest curriculum terminology
    topics: ['Essay', 'Exhibition', 'AOK comparison', 'Knowledge frameworks', 'Ways of knowing', 'Claims', 'Counterclaims', 'Implications & applications', 'Ethics'],
    description: 'TOK essay structure, exhibition object links, and argument balance.'
  },
  {
    id: 'turkish-b', name: 'Turkish B', level: 'HL/SL', icon: 'TR', color: 'teal',
    // Added Edebiyat analizi (literary analysis) for more advanced content
    topics: ['IO', 'Metin analizi', 'Edebiyat analizi', 'Küresel sorun', 'Dil ve üslup', 'Bireysel ve toplumsal değerler'],
    description: 'Basit ve etkili Türkçe analiz, sözlü planlama, ve teknik yorumlama.'
  }
  ,
  // Additional subjects to broaden coverage across the IB Diploma Programme. These
  // entries include typical topics drawn from official syllabi and provide
  // identifiers, icons and colours for use in the UI. They do not claim to
  // reproduce proprietary question bank content but offer original practice
  // prompts inspired by common curriculum themes.
  {
    id: 'biology', name: 'Biology', level: 'SL/HL', icon: 'β', color: 'forestgreen',
    topics: ['Cell biology', 'Molecular biology', 'Genetics', 'Ecology', 'Evolution', 'Physiology'],
    description: 'Explore the building blocks of life, genetic inheritance, ecology and human physiology with concept‑first practice.'
  },
  {
    id: 'chemistry', name: 'Chemistry', level: 'SL/HL', icon: '⚗', color: 'darkorange',
    topics: ['Stoichiometry', 'Atomic structure', 'Bonding', 'Energetics', 'Kinetics', 'Equilibrium', 'Acids and bases', 'Redox', 'Organic chemistry'],
    description: 'Practice calculations and explanations across physical, inorganic and organic chemistry topics.'
  },
  {
    id: 'economics', name: 'Economics', level: 'SL/HL', icon: '€', color: 'saddlebrown',
    topics: ['Microeconomics', 'Macroeconomics', 'International', 'Development'],
    description: 'Demand, supply, elasticity, macro policy and global development questions for HL/SL.'
  },
  {
    id: 'business', name: 'Business Management', level: 'SL/HL', icon: '💼', color: 'steelblue',
    topics: ['External environment', 'Human resources', 'Finance and accounts', 'Marketing', 'Operations'],
    description: 'Analyse case studies across marketing, finance, HR and operations to prepare for Paper 1 and 2.'
  },
  {
    id: 'history', name: 'History', level: 'SL/HL', icon: '⌛', color: 'maroon',
    topics: ['20th century wars', 'Authoritarian states', 'Cold War'],
    description: 'Essay prompts and source analysis aligned with Paper 2 and 3 for different regional options.'
  },
  {
    id: 'geography', name: 'Geography', level: 'SL/HL', icon: '🌍', color: 'olivedrab',
    topics: ['Population dynamics', 'Climate change', 'Resource consumption', 'Hazards'],
    description: 'Practice questions on global change, resources, and geographic hazards.'
  },
  {
    id: 'psychology', name: 'Psychology', level: 'SL/HL', icon: 'Ψ', color: 'mediumvioletred',
    topics: ['Biological approach', 'Cognitive approach', 'Sociocultural approach', 'Research methods'],
    description: 'Develop analysis skills across approaches and methodologies for Paper 1 and 2.'
  },
  {
    id: 'visual-arts', name: 'Visual Arts', level: 'SL/HL', icon: '🎨', color: 'peru',
    topics: ['Formal analysis', 'Materials and techniques', 'Themes and meanings', 'Curatorial practice'],
    description: 'Explore artistic elements, materials, concepts and exhibition curation.'
  },
  {
    id: 'ess', name: 'Environmental Systems', level: 'SL', icon: '🌱', color: 'seagreen',
    topics: ['Ecosystems', 'Biodiversity', 'Water and soil', 'Atmosphere and climate'],
    description: 'Interdisciplinary questions connecting ecology, biology and environmental science.'
  },
  {
    id: 'spanish-b', name: 'Spanish B', level: 'SL/HL', icon: 'ES', color: 'firebrick',
    topics: ['Intercultural understanding', 'Oral communication', 'Reading comprehension', 'Writing tasks'],
    description: 'Practise language skills and cultural understanding in Spanish as a second language.'
  }
];

const notes = [
  {
    id: 'n1', subject: 'math-aa-hl', title: 'Hessian matrix in an IA',
    summary: 'Use a Hessian when your optimization has more than one variable and a normal second derivative is no longer enough.',
    bullets: [
      'For one variable, the second derivative tells whether the curve bends up or down.',
      'For two variables, the Hessian collects all second partial derivatives in one matrix.',
      'A positive determinant with fxx > 0 suggests a local minimum; positive determinant with fxx < 0 suggests a local maximum.',
      'Explain it as a generalization of the syllabus second-derivative test.'
    ]
  },
  {
    id: 'n2', subject: 'physics-hl', title: 'Doppler effect with sound sensors',
    summary: 'For reflected sound, the frequency shift can happen twice: once as the wave reaches the moving object and once as it returns.',
    bullets: [
      'Sound is a mechanical wave, so use the sound-wave Doppler formula, not electromagnetic redshift formulas.',
      'Always define whether the source, observer, or reflecting surface is moving.',
      'For small speeds, reflected frequency change is approximately 2fv/c.'
    ]
  },
  {
    id: 'n3', subject: 'cs-hl', title: 'Abstract Data Types',
    summary: 'An ADT defines behaviour, not implementation. Stack and queue questions usually test operations and edge cases.',
    bullets: [
      'Stack: push, pop, peek, isEmpty; LIFO structure.',
      'Queue: enqueue, dequeue, front; FIFO structure.',
      'Circular queue prevents wasted array space by wrapping indices around.',
      'Mention overflow and underflow conditions in exam answers.'
    ]
  },
  {
    id: 'n4', subject: 'english-a', title: 'Authorial choices paragraph',
    summary: 'A strong paragraph links device, evidence, effect, and global issue instead of simply naming techniques.',
    bullets: [
      'Start with a clear claim about meaning.',
      'Embed short quotations instead of dropping long evidence.',
      'Analyze diction, imagery, structure, perspective, or contrast.',
      'End by linking back to the global issue or question.'
    ]
  },
  {
    id: 'n5', subject: 'tok', title: 'TOK essay balance',
    summary: 'A TOK essay should compare how knowledge works in different AOKs, not only tell examples.',
    bullets: [
      'Use examples to test the title, not decorate the paragraph.',
      'Make the method of each AOK visible.',
      'Include a counterclaim that genuinely challenges your first claim.',
      'Return to the title after each example.'
    ]
  },
  {
    id: 'n6', subject: 'turkish-b', title: 'IO küresel sorun bağlantısı',
    summary: 'Metindeki teknikleri sadece bulmak yetmez; tekniğin küresel sorunu nasıl görünür kıldığını açıklamalısın.',
    bullets: [
      'Alıntı kısa olmalı ve doğrudan yoruma bağlanmalı.',
      'Renk, tekrar, bakış, mekân ve nesneleşme gibi teknikleri işleve bağla.',
      'Her ana noktada metin ve küresel sorun ilişkisini açık tut.',
      'Konuşma dili sade ama analitik olmalı.'
    ]
  }
];

const questions = [
  {
    id: 'q1', subject: 'math-aa-hl', difficulty: 'hard', topic: 'Optimization', marks: 6,
    prompt: 'A student models alertness as A(t)=D₁e^{-kt}+D₂e^{-k(t-h)}. Explain why partial derivatives are needed to optimize D₁ and D₂ together.',
    answer: 'There are two independent dose variables, so changing only one at a time does not show the full behaviour of the objective function. Partial derivatives measure the effect of each variable while holding the other constant, and solving both conditions together identifies stationary points for the two-variable model.',
    markscheme: ['Identifies two independent variables.', 'Explains partial derivative as one-variable-at-a-time rate of change.', 'States both derivatives must equal zero at a stationary point.', 'Connects method to optimization.']
  },
  {
    id: 'q2', subject: 'physics-hl', difficulty: 'medium', topic: 'Waves', marks: 4,
    prompt: 'A string vibrates in its third harmonic. State the distance between consecutive nodes if the string length is L.',
    answer: 'For a string fixed at both ends, adjacent nodes are separated by half a wavelength. In the third harmonic, L = 3λ/2, so λ = 2L/3. Therefore node spacing = λ/2 = L/3.',
    markscheme: ['States adjacent nodes are λ/2 apart.', 'Uses L = 3λ/2.', 'Obtains λ = 2L/3.', 'Concludes spacing is L/3.']
  },
  {
    id: 'q3', subject: 'cs-hl', difficulty: 'easy', topic: 'Stacks', marks: 3,
    prompt: 'Outline one advantage of using a stack ADT instead of manually managing an array.',
    answer: 'A stack ADT hides implementation details and exposes clear operations such as push and pop. This makes code easier to understand, reduces errors, and allows the implementation to change without changing the rest of the program.',
    markscheme: ['Mentions abstraction/encapsulation.', 'Mentions stack operations.', 'Explains maintainability or reduced errors.']
  },
  {
    id: 'q4', subject: 'english-a', difficulty: 'medium', topic: 'Paper 1', marks: 5,
    prompt: 'Write a thesis for a visual advertisement that uses contrast between luxury imagery and environmental damage.',
    answer: 'The advertisement uses visual contrast, colour symbolism, and composition to expose how consumer desire can hide environmental harm behind attractive images of luxury.',
    markscheme: ['Clear argument.', 'Mentions techniques.', 'Mentions intended effect.', 'Connects to broader meaning.']
  },
  {
    id: 'q5', subject: 'tok', difficulty: 'hard', topic: 'AOK comparison', marks: 6,
    prompt: 'Why is controlled experimentation more central to the natural sciences than to history?',
    answer: 'Natural sciences often investigate repeatable phenomena, so controlled experiments can isolate variables and test causal claims. History reconstructs non-repeatable past events through evidence, interpretation, and source evaluation, so its method depends more on corroboration and context than direct experimental control.',
    markscheme: ['Defines controlled experimentation.', 'Explains repeatability in science.', 'Explains non-repeatability in history.', 'Compares methods directly.']
  },
  {
    id: 'q6', subject: 'physics-hl', difficulty: 'hard', topic: 'Electric potential', marks: 5,
    prompt: 'A conducting sphere has surface potential 53.9 kV. At 2.8 m from the centre, potential is 7.71 kV. Determine the radius.',
    answer: 'Outside a charged conducting sphere, V = kQ/r. At the surface, V_surface = kQ/R. Therefore V_surface / V_at_point = r/R, so R = r × V_at_point / V_surface = 2.8 × 7.71 / 53.9 ≈ 0.40 m.',
    markscheme: ['Uses V = kQ/r outside sphere.', 'Sets ratio correctly.', 'Substitutes values.', 'Gives radius about 0.40 m with unit.']
  },
  {
    id: 'q7', subject: 'cs-hl', difficulty: 'medium', topic: 'Circular queue', marks: 5,
    prompt: 'Explain how a circular queue avoids wasting space after several dequeue operations.',
    answer: 'In a normal linear array queue, dequeued positions at the front may remain unused. A circular queue uses modulo arithmetic so rear and front indices wrap back to the beginning of the array, allowing empty spaces to be reused as long as the queue is not full.',
    markscheme: ['Mentions front/rear indices.', 'Explains wasted front spaces.', 'Mentions wraparound.', 'Mentions modulo or circular movement.', 'Connects to efficient fixed-size array use.']
  },
  {
    id: 'q8', subject: 'math-aa-hl', difficulty: 'medium', topic: 'Complex numbers', marks: 4,
    prompt: 'Explain why complex roots of real polynomial equations occur in conjugate pairs.',
    answer: 'If the polynomial has real coefficients, conjugating the equation preserves every real coefficient and operation. Therefore, when a + bi is a root, substituting a − bi also makes the polynomial equal zero.',
    markscheme: ['Mentions real coefficients.', 'Mentions conjugation preserves equation.', 'States roots occur as a ± bi.']
  },
  {
    id: 'q9', subject: 'english-a', difficulty: 'hard', topic: 'IO', marks: 6,
    prompt: 'How can a domestic setting be used to reveal greed in a literary extract?',
    answer: 'A domestic setting can make greed feel invasive because private space becomes controlled by wealth, status, or possession. When ordinary objects are transformed into symbols of power, the text shows how greed damages intimacy and turns human relationships into displays of ownership.',
    markscheme: ['Connects setting to meaning.', 'Explains invasion of private space.', 'Mentions objects/symbols.', 'Links greed to damaged relationships.']
  }
  ,
  // Additional questions to expand the bank. These cover more syllabus‑aligned topics across
  // subjects and help organize the question bank by topic. Each question uses
  // a unique identifier and includes a topic, difficulty, marks, prompt, answer and markscheme.
  {
    id: 'q10', subject: 'math-aa-hl', difficulty: 'medium', topic: 'Integration', marks: 5,
    prompt: 'Use integration by parts to evaluate ∫ x e^x dx.',
    answer: 'Let u = x and dv = e^x dx. Then du = dx and v = e^x. By integration by parts, ∫ x e^x dx = x e^x − ∫ e^x dx = x e^x − e^x + C = e^x(x − 1) + C.',
    markscheme: ['Chooses u = x and dv = e^x.', 'Computes du and v correctly.', 'Applies the integration by parts formula.', 'Simplifies to e^x(x − 1) + C.']
  },
  {
    id: 'q11', subject: 'math-aa-hl', difficulty: 'medium', topic: 'Probability', marks: 4,
    prompt: 'A fair six‑sided die is rolled twice. Find the probability that the sum is 8.',
    answer: 'Pairs that sum to 8 are (2,6), (3,5), (4,4), (5,3), (6,2). There are 5 favourable outcomes out of 36 equally likely pairs, so the probability is 5/36.',
    markscheme: ['Lists the favourable pairs.', 'Identifies 5 favourable outcomes.', 'Recognises 36 total outcomes.', 'Computes probability as 5/36.']
  },
  {
    id: 'q12', subject: 'physics-hl', difficulty: 'medium', topic: 'Mechanics', marks: 5,
    prompt: 'A ball is launched horizontally from a 20 m high cliff with speed 10 m/s. Neglecting air resistance, calculate the horizontal distance travelled when it hits the ground.',
    answer: 'Time to fall 20 m is found using s = ½gt² ⇒ 20 = ½ × 9.81 × t², giving t ≈ 2.02 s. Horizontal distance = vₓ × t = 10 × 2.02 ≈ 20.2 m.',
    markscheme: ['Uses s = ½gt² to find t.', 'Substitutes g = 9.81 m/s².', 'Solves for t ≈ 2.02 s.', 'Multiplies by horizontal speed to get distance.']
  },
  {
    id: 'q13', subject: 'physics-hl', difficulty: 'hard', topic: 'Modern physics', marks: 6,
    prompt: 'Explain how the photoelectric effect demonstrates the particle nature of light and derive an expression for the maximum kinetic energy of emitted electrons.',
    answer: 'The photoelectric effect shows that electrons are emitted only when light of sufficient frequency is incident, regardless of intensity, indicating quantized energy packets (photons). Each photon has energy hf and a minimum energy (work function φ) is required to overcome the binding energy. The maximum kinetic energy is therefore Kₘₐₓ = hf − φ.',
    markscheme: ['States emission depends on frequency not intensity.', 'Identifies energy quantization via photons.', 'Mentions work function φ.', 'Derives Kₘₐₓ = hf − φ.']
  },
  {
    id: 'q14', subject: 'cs-hl', difficulty: 'medium', topic: 'Linked lists', marks: 4,
    prompt: 'Give one benefit and one drawback of using a singly linked list instead of an array.',
    answer: 'Linked lists allow efficient insertions and deletions without shifting elements because nodes point to the next node. However, they have higher memory overhead and accessing an element by index requires traversing from the head, so random access is slower.',
    markscheme: ['Mentions efficient insertion/deletion.', 'Explains pointer/link structure.', 'Mentions memory overhead.', 'Notes lack of constant‑time random access.']
  },
  {
    id: 'q15', subject: 'cs-hl', difficulty: 'medium', topic: 'Searching algorithms', marks: 4,
    prompt: 'Describe the binary search algorithm and state one requirement for using it.',
    answer: 'Binary search repeatedly divides a sorted array in half, comparing the target value to the middle element to decide whether to search the left or right half until the target is found or the search interval is empty. It requires that the list be sorted in order for comparisons to eliminate half of the remaining elements each step.',
    markscheme: ['Explains halving process.', 'Mentions comparing with middle element.', 'Describes termination condition.', 'States requirement that the list be sorted.']
  },
  {
    id: 'q16', subject: 'english-a', difficulty: 'medium', topic: 'Paper 2', marks: 5,
    prompt: 'Compare how two different poems use imagery to convey emotion.',
    answer: 'Both poems employ vivid imagery to evoke feelings: the first uses nature imagery to convey serenity through descriptions of flowing water and birdsong, while the second uses stark urban imagery, such as concrete and sirens, to create tension. The juxtaposition of these images highlights the poets’ contrasting emotional landscapes.',
    markscheme: ['Identifies imagery in both poems.', 'Explains the effect of nature imagery.', 'Explains the effect of urban imagery.', 'Discusses contrast between emotions.', 'Connects imagery to overall mood.']
  },
  {
    id: 'q17', subject: 'english-a', difficulty: 'easy', topic: 'Rhetoric', marks: 3,
    prompt: 'What is the effect of rhetorical questions in persuasive writing?',
    answer: 'Rhetorical questions engage the reader by prompting reflection without expecting an answer. They can emphasize key points, create emotional resonance, and guide the audience toward the writer’s perspective.',
    markscheme: ['Mentions engagement of the reader.', 'Explains emphasis on key points.', 'Notes emotional or guiding effect.']
  },
  {
    id: 'q18', subject: 'tok', difficulty: 'medium', topic: 'Knowledge frameworks', marks: 5,
    prompt: 'Distinguish between personal knowledge and shared knowledge in the Theory of Knowledge framework.',
    answer: 'Personal knowledge is acquired through individual experience, perspective and skill; it is subjective and often tacit. Shared knowledge is developed collectively within cultures or disciplines, recorded in languages and systems, and can be communicated and verified by others.',
    markscheme: ['Defines personal knowledge.', 'Defines shared knowledge.', 'Highlights subjectivity and individuality.', 'Mentions collective development and verification.', 'Notes communication through language or systems.']
  },
  {
    id: 'q19', subject: 'tok', difficulty: 'medium', topic: 'Ways of knowing', marks: 4,
    prompt: 'Explain the role of emotion as a way of knowing and one limitation associated with it.',
    answer: 'Emotion influences perception and decision making by colouring experiences with personal significance and motivating action. It can provide insight into values and empathy, but emotions can also bias reasoning and lead to hasty conclusions if not balanced with other ways of knowing.',
    markscheme: ['Describes emotion’s influence on knowing.', 'Mentions insight into values or empathy.', 'Identifies bias or hasty conclusions.', 'Emphasises need to balance with other WoKs.']
  },
  {
    id: 'q20', subject: 'turkish-b', difficulty: 'medium', topic: 'Edebiyat analizi', marks: 5,
    prompt: 'Bir edebî eserde zaman kavramı nasıl kullanılır ve bu kullanımın metnin anlamına etkisi nedir?',
    answer: 'Zaman sıralaması ve kırılmaları, olayların akışını düzenler ve gerilim yaratır. Geriye dönüş (flashback) veya ileriye sıçrama (flashforward) teknikleri karakterlerin geçmişi veya geleceği hakkında bilgi vererek okurun metni daha derin anlamasına katkı sağlar.',
    markscheme: ['Zaman sıralaması ve kırılmalarını açıklar.', 'Gerilim yaratma etkisinden bahseder.', 'Geriye dönüş ve ileriye sıçrama örneklerini verir.', 'Okurun anlamasına katkısını açıklar.']
  }
  ,
  // Added additional questions across all subjects to align more closely with the IB syllabus.
  {
    id: 'q21', subject: 'math-aa-hl', difficulty: 'hard', topic: 'Vectors', marks: 6,
    prompt: 'Two vectors $\mathbf{a}$ and $\mathbf{b}$ in three dimensions have magnitudes |\mathbf{a}| = 3 and |\mathbf{b}| = 4 with dot product \(\mathbf{a}\cdot\mathbf{b}=5\). Calculate the angle between the vectors.',
    answer: 'The angle \(\theta\) satisfies \(\cos\theta = \frac{\mathbf{a}\cdot\mathbf{b}}{|\mathbf{a}|\,|\mathbf{b}|} = \frac{5}{3 \times 4} = \tfrac{5}{12}\). Therefore \(\theta = \cos^{-1}(5/12)\).',
    markscheme: ['Uses the formula \(\mathbf{a}\cdot\mathbf{b}=|\mathbf{a}||\mathbf{b}|\cos\theta\).', 'Substitutes the magnitudes and dot product.', 'Solves for \(\cos\theta=5/12\).', 'States \(\theta=\cos^{-1}(5/12)\).']
  },
  {
    id: 'q22', subject: 'math-aa-hl', difficulty: 'medium', topic: 'Statistics', marks: 4,
    prompt: 'A data set of 10 numbers has a mean of 7 and a variance of 4. If each number is increased by 3, what are the new mean and variance?',
    answer: 'Adding a constant shifts the mean by that constant but does not change the variance. The new mean is 10 and the variance remains 4.',
    markscheme: ['Recognises that adding a constant shifts the mean by the same amount.', 'States the new mean is 10.', 'Explains that variance is unchanged by adding a constant.', 'Gives variance as 4.']
  },
  {
    id: 'q23', subject: 'math-aa-hl', difficulty: 'medium', topic: 'Functions', marks: 4,
    prompt: 'Explain the difference between the domain and range of a function and provide an example.',
    answer: 'The domain of a function is the set of all allowable input values, while the range is the set of all possible outputs. For example, for \(f(x)=x^2\) the domain can be all real numbers and the range is all real numbers greater than or equal to zero.',
    markscheme: ['Defines domain as allowable inputs.', 'Defines range as possible outputs.', 'Provides a concrete example.', 'Correctly identifies domain and range in the example.']
  },
  {
    id: 'q24', subject: 'physics-hl', difficulty: 'medium', topic: 'Gravitational fields', marks: 5,
    prompt: 'State the expression for the gravitational potential energy of two point masses M and m separated by a distance r and explain why the value is negative.',
    answer: 'The gravitational potential energy is given by \(U = -\frac{GMm}{r}\). The negative sign indicates that gravitational forces are attractive; work must be done to separate the masses to infinity, which is defined as zero potential energy, so nearer separations have less (negative) potential energy.',
    markscheme: ['Writes the expression \(U = -GMm/r\).', 'Mentions the negative sign.', 'Explains that gravity is attractive and that energy is required to separate masses.', 'Connects zero potential energy to infinite separation.']
  },
  {
    id: 'q25', subject: 'physics-hl', difficulty: 'medium', topic: 'Waves', marks: 5,
    prompt: 'Describe the Doppler effect and write down a formula for the observed frequency when a source is moving toward a stationary observer.',
    answer: 'The Doppler effect refers to the change in observed frequency when there is relative motion between a source and an observer. For a source moving toward a stationary observer, the observed frequency is \(f’ = f \frac{v}{v - v_s}\), where v is the wave speed, f is the emitted frequency and v_s is the speed of the source toward the observer.',
    markscheme: ['Defines the Doppler effect as a change in frequency due to relative motion.', 'Provides the correct formula.', 'Identifies variables correctly (v is wave speed, v_s is source speed).', 'Notes the source moving toward the observer increases the observed frequency.']
  },
  {
    id: 'q26', subject: 'physics-hl', difficulty: 'hard', topic: 'Fields', marks: 6,
    prompt: 'Define electric field strength at a point and describe how it relates to the electric potential gradient.',
    answer: 'The electric field strength at a point is the force per unit positive charge experienced by a small test charge placed at that point. It equals the negative gradient of the electric potential: \(E = -\mathrm{d}V/\mathrm{d}r\). Thus field lines are perpendicular to equipotential surfaces and point in the direction of decreasing potential.',
    markscheme: ['Defines electric field strength as force per unit charge.', 'States the relation \(E = -\mathrm{d}V/\mathrm{d}r\).', 'Mentions that the negative sign means the field points toward lower potential.', 'Notes that field lines are perpendicular to equipotential surfaces.']
  },
  {
    id: 'q27', subject: 'cs-hl', difficulty: 'medium', topic: 'OOP', marks: 4,
    prompt: 'Explain the principle of encapsulation in object‑oriented programming and give one benefit of using it.',
    answer: 'Encapsulation bundles data and the methods that operate on that data into a single unit (class) and restricts direct access to the internal state by making fields private and providing getters/setters. This hides implementation details, preventing unintended interference and improving modularity and maintainability.',
    markscheme: ['Defines encapsulation as bundling data with operations.', 'Mentions access restrictions via private fields or methods.', 'Explains hiding implementation details.', 'States a benefit such as improved modularity or reduced errors.']
  },
  {
    id: 'q28', subject: 'cs-hl', difficulty: 'medium', topic: 'Databases', marks: 4,
    prompt: 'Distinguish between a primary key and a foreign key in a relational database.',
    answer: 'A primary key uniquely identifies each record in a table and cannot be null. A foreign key is a field in one table that references the primary key of another table, establishing a relationship between the tables and enforcing referential integrity.',
    markscheme: ['Defines primary key and notes uniqueness and non‑null.', 'Defines foreign key and notes it references another table.', 'Mentions referential integrity or relational linkage.', 'Contrasts the two roles.']
  },
  {
    id: 'q29', subject: 'cs-hl', difficulty: 'medium', topic: 'Networks', marks: 4,
    prompt: 'What is the purpose of the TCP protocol in the Internet protocol suite?',
    answer: 'TCP (Transmission Control Protocol) provides reliable, ordered, and error‑checked delivery of data between applications over the network. It establishes a connection, manages data packet sequencing, retransmits lost packets and performs flow control to ensure the receiver can handle incoming data.',
    markscheme: ['Identifies TCP as providing reliable data transfer.', 'Mentions ordered delivery and error checking.', 'Notes connection establishment and retransmission of lost packets.', 'Mentions flow control or congestion management.']
  },
  {
    id: 'q30', subject: 'cs-hl', difficulty: 'medium', topic: 'Web apps', marks: 4,
    prompt: 'Compare client‑side rendering and server‑side rendering in web applications.',
    answer: 'Client‑side rendering means that the browser downloads a minimal HTML shell and uses JavaScript to generate content, leading to slower initial loads but more dynamic interactions once loaded. Server‑side rendering generates the full HTML on the server before sending it to the client, resulting in faster initial page loads and better SEO but requiring full reloads or extra API calls for updates.',
    markscheme: ['Defines client‑side rendering and notes slower initial load/dynamic interaction.', 'Defines server‑side rendering and notes faster initial load and SEO benefits.', 'Mentions where rendering occurs (client vs server).', 'Discusses trade‑offs such as update handling.']
  },
  {
    id: 'q31', subject: 'english-a', difficulty: 'medium', topic: 'Thesis writing', marks: 4,
    prompt: 'What makes an effective thesis statement in a comparative literary essay?',
    answer: 'An effective thesis statement presents a clear, arguable position that directly compares the texts on a specific theme or technique. It should be debatable, provide direction for the essay’s analysis and unify the discussion rather than simply listing topics.',
    markscheme: ['States that the thesis should be clear and arguable.', 'Emphasises that it must make a comparison.', 'Notes that it provides direction for analysis.', 'Warns against mere listing of topics.']
  },
  {
    id: 'q32', subject: 'english-a', difficulty: 'medium', topic: 'Authorial choices', marks: 4,
    prompt: 'Define the term motif in literature and explain how an author might use a recurring motif to develop a theme.',
    answer: 'A motif is a recurring element—such as an image, phrase, or symbol—that carries thematic significance. By repeating a motif in different contexts, an author reinforces certain ideas or emotions and helps develop the overarching theme throughout the text.',
    markscheme: ['Defines motif as a recurring element with thematic significance.', 'Explains that it can be an image, phrase or symbol.', 'Describes how repetition reinforces ideas or emotions.', 'Connects motif use to theme development.']
  },
  {
    id: 'q33', subject: 'tok', difficulty: 'medium', topic: 'Claims', marks: 4,
    prompt: 'Why is it important to distinguish between correlation and causation when making knowledge claims?',
    answer: 'Correlation simply means two variables change together, while causation indicates that one variable directly influences the other. Mistaking correlation for causation can lead to inaccurate claims; careful analysis of mechanisms and evidence is necessary to ensure reliability of knowledge claims.',
    markscheme: ['Defines correlation.', 'Defines causation.', 'Explains the risk of incorrectly inferring causation from correlation.', 'Notes the need for evidence and mechanism.']
  },
  {
    id: 'q34', subject: 'tok', difficulty: 'medium', topic: 'Counterclaims', marks: 4,
    prompt: 'Describe how including a counterclaim can strengthen an argument in a Theory of Knowledge essay.',
    answer: 'Presenting a counterclaim demonstrates awareness of alternative perspectives. By addressing and refuting opposing views, the essay achieves greater balance and depth, making the original argument more robust and credible.',
    markscheme: ['Mentions acknowledgment of alternative perspectives.', 'Explains addressing and refuting opposing views.', 'States that it adds balance or depth.', 'Notes improved credibility of the argument.']
  },
  {
    id: 'q35', subject: 'turkish-b', difficulty: 'medium', topic: 'Küresel sorun', marks: 4,
    prompt: 'Küresel sorun kavramını tanımlayın ve metin analizi yaparken neden önemlidir?',
    answer: 'Küresel sorun, sınırları aşan ve tüm insanlığı etkileyen çevresel, sosyal, ekonomik veya siyasi sorundur. Metin analizinde, yazarın eseri dünya ölçeğindeki temalarla ilişkilendirilerek okurun metnin evrenselliğini ve güncelliğini anlaması sağlanır.',
    markscheme: ['Küresel sorunu tanımlar.', 'Çevresel, sosyal, ekonomik veya siyasi boyutlara değinir.', 'Metin analizinde yazarın temalarını bağlamaya odaklanır.', 'Evrensellik ve güncellik vurgusu yapar.']
  },
  {
    id: 'q36', subject: 'turkish-b', difficulty: 'medium', topic: 'Dil ve üslup', marks: 4,
    prompt: 'Bir metinde yazarın dil ve üslup seçimleri okuyucunun algısını nasıl etkiler?',
    answer: 'Yazarın kelime dağarcığı, cümle yapısı, anlatım biçimi ve tonu, okuyucunun metni nasıl anladığını ve hissettiğini belirler. Sade ve açık bir üslup erişilebilirlik sağlarken betimleyici ve imgeli bir üslup atmosfer kurar ve duygusal etkiyi artırır.',
    markscheme: ['Kelime ve cümle seçimlerine vurgu yapar.', 'Anlatım biçimi ve tonun önemini açıklar.', 'Sade üslubun erişilebilirliğini belirtir.', 'Betimleyici üslubun atmosfer yaratma etkisini açıklar.']
  }
  ,
  // New questions for additional IB subjects. These are original practice
  // problems designed to reflect common syllabus themes without copying
  // proprietary exam content. Each includes a topic, difficulty, marks, and
  // a succinct answer with key points in the markscheme.
  {
    id: 'q37', subject: 'biology', difficulty: 'easy', topic: 'Cell biology', marks: 3,
    prompt: 'State two differences between prokaryotic and eukaryotic cells.',
    answer: 'Prokaryotic cells lack a membrane‑bound nucleus and membrane‑bound organelles; their DNA is found in a nucleoid region and they are generally smaller. Eukaryotic cells have a true nucleus and organelles such as mitochondria and are larger.',
    markscheme: ['Notes absence of membrane‑bound nucleus in prokaryotes.', 'Mentions lack of membrane‑bound organelles.', 'States relative size difference or location of DNA.', 'States presence of nucleus and organelles in eukaryotes.']
  },
  {
    id: 'q38', subject: 'biology', difficulty: 'easy', topic: 'Genetics', marks: 3,
    prompt: 'Two parents are heterozygous for a recessive allele causing a genetic disease. What is the probability their child will express the disease?',
    answer: 'When both parents are carriers (Aa), the genotype ratios in the offspring are 1 AA : 2 Aa : 1 aa. Only the homozygous recessive genotype (aa) expresses the disease, giving a probability of 1/4.',
    markscheme: ['Correctly identifies genotype ratio 1:2:1.', 'States that only aa expresses the disease.', 'Calculates probability as 25 % or 1/4.']
  },
  {
    id: 'q39', subject: 'chemistry', difficulty: 'medium', topic: 'Stoichiometry', marks: 5,
    prompt: 'Balance the equation for the complete combustion of propane (C₃H₈) and calculate the volume of CO₂ produced at STP from 2.0 moles of propane.',
    answer: 'The balanced equation is C₃H₈ + 5 O₂ → 3 CO₂ + 4 H₂O. Two moles of propane produce 2 × 3 = 6 moles of CO₂. At STP one mole of gas occupies 22.7 L, so the volume of CO₂ is 6 × 22.7 ≈ 136 L.',
    markscheme: ['Writes balanced equation C₃H₈ + 5 O₂ → 3 CO₂ + 4 H₂O.', 'Determines molar ratio of CO₂ to C₃H₈ as 3:1.', 'Calculates 6 moles of CO₂ from 2 moles C₃H₈.', 'Uses molar volume 22.7 L at STP.', 'Computes approximate volume 136 L.']
  },
  {
    id: 'q40', subject: 'economics', difficulty: 'medium', topic: 'Microeconomics', marks: 4,
    prompt: 'Define price elasticity of demand and describe one factor that influences its value.',
    answer: 'Price elasticity of demand measures the responsiveness of quantity demanded to a change in price, calculated as the percentage change in quantity over the percentage change in price. One factor affecting it is the availability of close substitutes: goods with many substitutes tend to have more elastic demand.',
    markscheme: ['Defines price elasticity as responsiveness of quantity demanded to price change.', 'Includes formula (percentage change in Q divided by percentage change in price).', 'Identifies a factor such as substitutes, necessity versus luxury, or time horizon.', 'Explains how the factor influences elasticity.']
  },
  {
    id: 'q41', subject: 'business', difficulty: 'medium', topic: 'Marketing', marks: 4,
    prompt: 'What is market segmentation and why is it beneficial for a business?',
    answer: 'Market segmentation is the process of dividing a broad market into smaller groups of consumers with similar characteristics or needs. It allows a business to tailor its marketing mix to target specific segments more effectively, improving customer satisfaction and resource efficiency.',
    markscheme: ['Defines market segmentation as dividing a market into groups.', 'Mentions bases such as demographics, psychographics or behaviour.', 'Explains that segmentation enables targeted marketing strategies.', 'States benefits such as improved customer satisfaction or efficient resource use.']
  },
  {
    id: 'q42', subject: 'history', difficulty: 'medium', topic: 'Cold War', marks: 5,
    prompt: 'Discuss one significant cause of the Cuban Missile Crisis of 1962.',
    answer: 'One significant cause was the escalation of superpower tensions: after the failed Bay of Pigs invasion and the US deployment of Jupiter missiles in Turkey, the Soviet Union aimed to protect its ally Cuba and restore the balance of power by placing nuclear missiles on the island, leading to the crisis.',
    markscheme: ['Identifies a valid cause (e.g., US missiles in Turkey, Bay of Pigs invasion, superpower competition).', 'Explains the Soviet rationale for deploying missiles in Cuba.', 'Mentions desire to protect Cuba or restore balance.', 'Links the cause to the escalation of tensions leading to the crisis.', 'Provides historical context or details.']
  },
  {
    id: 'q43', subject: 'geography', difficulty: 'medium', topic: 'Climate change', marks: 4,
    prompt: 'Differentiate between mitigation and adaptation strategies for climate change, providing an example of each.',
    answer: 'Mitigation strategies aim to reduce the causes of climate change by lowering greenhouse gas emissions (e.g., switching to renewable energy). Adaptation strategies aim to adjust to the effects of climate change, such as building flood defences or modifying agricultural practices to cope with altered rainfall patterns.',
    markscheme: ['Defines mitigation as reducing causes of climate change.', 'Provides example of mitigation (renewable energy, reforestation, efficiency).', 'Defines adaptation as adjusting to effects.', 'Provides example of adaptation (flood defences, drought‑resistant crops, coastal relocation).']
  },
  {
    id: 'q44', subject: 'psychology', difficulty: 'medium', topic: 'Research methods', marks: 4,
    prompt: 'Why is random allocation of participants important in experimental research in psychology?',
    answer: 'Random allocation assigns participants to experimental conditions by chance, ensuring that pre‑existing differences are evenly distributed. This reduces selection bias, increases internal validity and allows researchers to infer that observed effects are due to the manipulated variable rather than other factors.',
    markscheme: ['Explains random allocation distributes participants by chance.', 'Notes it reduces selection bias and confounding variables.', 'Mentions internal validity.', 'Links random allocation to establishing causal relationships.']
  },
  {
    id: 'q45', subject: 'visual-arts', difficulty: 'medium', topic: 'Formal analysis', marks: 4,
    prompt: 'Name two elements of art and explain how each can influence the mood of a painting.',
    answer: 'Colour and line are two elements of art. Warm colours (reds, oranges) can create feelings of warmth or excitement, while cool colours (blues, greens) can evoke calmness or melancholy. Thick, jagged lines can convey tension or aggression, whereas smooth, flowing lines can suggest peace or gentleness.',
    markscheme: ['Names at least two elements of art such as colour, line, shape, texture.', 'Explains an emotional effect for each element.', 'Provides specific examples (warm vs cool colours, jagged vs smooth lines).', 'Links elements to mood of the painting.']
  },
  {
    id: 'q46', subject: 'ess', difficulty: 'medium', topic: 'Ecosystems', marks: 5,
    prompt: 'Define ecological succession and distinguish between primary and secondary succession.',
    answer: 'Ecological succession is the process of sequential change in the species composition of a community over time. Primary succession occurs on newly exposed surfaces where no soil exists, such as after a lava flow or glacier retreat, beginning with pioneer species. Secondary succession occurs in areas where a community has been disturbed but soil and some organisms remain, such as after a fire or human clearing.',
    markscheme: ['Defines ecological succession as sequential community change.', 'Distinguishes primary succession (no soil, pioneer species) and gives an example.', 'Distinguishes secondary succession (soil present, disturbance) and gives an example.', 'Notes that primary succession starts from bare substrate while secondary does not.']
  },
  {
    id: 'q47', subject: 'spanish-b', difficulty: 'easy', topic: 'Oral communication', marks: 3,
    prompt: 'Suggest one strategy for improving fluency when speaking Spanish in spontaneous conversations.',
    answer: 'Practise speaking with native or fluent speakers regularly, focusing on thinking in Spanish rather than translating from your first language. Memorising common phrases and connectors and immersing yourself in Spanish media can also build automaticity and confidence.',
    markscheme: ['Recommends regular conversation practice or language exchange.', 'Mentions thinking in Spanish or reducing translation.', 'Suggests memorising phrases/connectors or immersion in Spanish media.', 'Explains that these strategies build fluency/confidence.']
  }
  ,
  // Additional practice questions across all IB subjects. These new items extend
  // coverage to core curriculum topics such as geometry, differentiation,
  // thermal physics, macroeconomics and more. Each question is original and
  // reflects typical IB learning outcomes without copying specific exam
  // content. Where calculations are required, approximate numerical values
  // are provided for clarity.
  {
    id: 'q48', subject: 'math-aa-hl', difficulty: 'medium', topic: 'Geometry & Trigonometry', marks: 4,
    prompt: 'In \u0394ABC with sides 7\,cm and 8\,cm enclosing an angle of 60\u00b0, find the area of the triangle.',
    answer: 'The area of a triangle with two sides a, b and included angle C is \u00bd ab \u00b7 \sin C. Substituting a = 7, b = 8 and C = 60\u00b0 gives area = 0.5 \u00d7 7 \u00d7 8 \u00d7 \sin(60\u00b0) = 28 \u00d7 \sqrt{3}/2 \approx 24.2\,\text{cm}^2.',
    markscheme: ['States area formula \u00bd ab \sin C.', 'Substitutes a=7, b=8 and C=60\u00b0.', 'Computes \sin 60\u00b0 = \sqrt{3}/2.', 'Obtains numerical area \u2248 24.2\,cm^2.']
  },
  {
    id: 'q49', subject: 'math-aa-hl', difficulty: 'easy', topic: 'Differentiation', marks: 4,
    prompt: 'Find the equation of the tangent line to the curve y = x^3 - 2x at x = 2.',
    answer: 'The derivative y\' = 3x^2 - 2. At x=2 the slope is 3\cdot4 - 2 = 10 and the point on the curve is (2, 2^3 - 2\cdot2) = (2, 4). The tangent line in point-slope form is y - 4 = 10(x - 2), which rearranges to y = 10x - 16.',
    markscheme: ['Differentiates y = x^3 - 2x to obtain y\' = 3x^2 - 2.', 'Evaluates the derivative at x = 2 to find slope 10.', 'Finds the point on the curve (2,4).', 'Writes tangent line y - 4 = 10(x - 2) or equivalent.']
  },
  {
    id: 'q50', subject: 'math-aa-hl', difficulty: 'easy', topic: 'Sequences & Series', marks: 3,
    prompt: 'Evaluate the sum to infinity of the geometric series 5 + 2.5 + 1.25 + \dots.',
    answer: 'The first term is a = 5 and the common ratio r = 0.5. The sum to infinity of a convergent geometric series is a/(1 - r), so the sum is 5/(1 - 0.5) = 10.',
    markscheme: ['Identifies a = 5 and r = 1/2.', 'Recalls formula S_\u221e = a/(1 - r).', 'Substitutes values correctly.', 'States the sum is 10.']
  },
  {
    id: 'q51', subject: 'physics-hl', difficulty: 'easy', topic: 'Thermal physics', marks: 4,
    prompt: 'Define specific heat capacity and derive the expression Q = mc\u0394T.',
    answer: 'Specific heat capacity c is the energy required to raise the temperature of 1\,kg of a substance by 1\,K. For a mass m experiencing a temperature change \u0394T, the thermal energy transferred is proportional to m and \u0394T with constant c: Q = mc\u0394T.',
    markscheme: ['Defines specific heat capacity as energy per kilogram per Kelvin.', 'States energy transferred \u220f m and \u220f \u0394T.', 'Introduces constant c.', 'Derives Q = mc\u0394T.']
  },
  {
    id: 'q52', subject: 'physics-hl', difficulty: 'medium', topic: 'Oscillations & SHM', marks: 4,
    prompt: 'A mass-spring system oscillates with amplitude 0.10\,m and angular frequency 5\,rad\,s^{\u22121}. Determine the maximum speed and maximum acceleration of the mass.',
    answer: 'For simple harmonic motion, the maximum speed is A\omega and the maximum acceleration is A\omega^2. Substituting A = 0.10\,m and \omega = 5\,rad\,s^{\u22121} gives v_{\text{max}} = 0.10 \u00d7 5 = 0.50\,m\,s^{\u22121} and a_{\text{max}} = 0.10 \u00d7 5^2 = 2.5\,m\,s^{\u22122}.',
    markscheme: ['Recalls v_{max} = A\omega and a_{max} = A\omega^2 for SHM.', 'Substitutes A = 0.10 m.', 'Substitutes \omega = 5 rad s^{-1}.', 'Calculates v_{max} = 0.50 m s^{-1} and a_{max} = 2.5 m s^{-2}.']
  },
  {
    id: 'q53', subject: 'physics-hl', difficulty: 'medium', topic: 'Nuclear & particle physics', marks: 4,
    prompt: 'Distinguish between nuclear fission and nuclear fusion and give one example of each.',
    answer: 'Nuclear fission is the process in which a heavy nucleus splits into two lighter nuclei, releasing energy; an example is the fission of uranium-235 in nuclear reactors. Nuclear fusion is the process where two light nuclei combine to form a heavier nucleus with energy release; an example is the fusion of hydrogen isotopes into helium in the Sun.',
    markscheme: ['Defines fission as splitting of a heavy nucleus.', 'Defines fusion as combining of light nuclei.', 'Mentions energy release in both processes.', 'Provides valid examples such as U‑235 fission and hydrogen fusion in stars.']
  },
  {
    id: 'q54', subject: 'cs-hl', difficulty: 'medium', topic: 'Complexity', marks: 4,
    prompt: 'What is Big O notation and how does it help describe the efficiency of an algorithm?',
    answer: 'Big O notation provides an upper bound on how a function grows as its input size increases. In algorithm analysis it describes the worst‑case runtime or memory usage, ignoring constant factors, and allows comparison of algorithms based on their growth rates (e.g., O(n), O(n^2)).',
    markscheme: ['Defines Big O as an upper bound on growth rate.', 'Relates Big O to algorithm time or space complexity.', 'Mentions worst‑case or asymptotic behaviour.', 'Notes that it ignores constant factors and helps compare algorithms.']
  },
  {
    id: 'q55', subject: 'cs-hl', difficulty: 'easy', topic: 'Recursion', marks: 3,
    prompt: 'Give one advantage and one disadvantage of using recursion instead of iteration in programming.',
    answer: 'Recursion can simplify code and reflect the structure of some problems (like tree traversal) more naturally, making algorithms easier to understand. However, recursive calls consume stack memory and involve overhead; for large inputs they can cause stack overflow and may be less efficient than iterative solutions.',
    markscheme: ['States that recursion can simplify code or mirror problem structure.', 'Provides an example context such as tree traversal.', 'Mentions increased memory use or function call overhead.', 'Notes risk of stack overflow or inefficiency.']
  },
  {
    id: 'q56', subject: 'english-a', difficulty: 'medium', topic: 'Motifs', marks: 4,
    prompt: 'Provide an example of a motif in a literary work and explain its thematic significance.',
    answer: 'In Shakespeare\'s Macbeth, the recurring motif of blood symbolises guilt and the violent consequences of ambition. Each appearance of blood imagery—whether literal or figurative—reinforces the theme that unchecked ambition leads to moral corruption and cannot be washed away.',
    markscheme: ['Identifies a specific motif in a named work.', 'Explains what the motif symbolises.', 'Links the motif to a central theme such as guilt or ambition.', 'Describes how repetition reinforces the theme.']
  },
  {
    id: 'q57', subject: 'english-a', difficulty: 'medium', topic: 'Narrative voice', marks: 4,
    prompt: 'How does a first‑person narrative voice influence the reader’s perception of events?',
    answer: 'A first‑person narrative limits the story to one character\'s perspective, allowing intimate access to their thoughts and feelings. This can create empathy and subjective insight but may also be unreliable or biased, influencing how readers interpret events and other characters.',
    markscheme: ['Mentions limitation to a single perspective.', 'Explains creation of intimacy or empathy.', 'Notes potential unreliability or bias.', 'Discusses impact on interpretation of events.']
  },
  {
    id: 'q58', subject: 'tok', difficulty: 'medium', topic: 'Implications & applications', marks: 4,
    prompt: 'In Theory of Knowledge, why is it important to consider the implications and applications of knowledge claims?',
    answer: 'Considering implications and applications helps learners recognise the consequences of accepting knowledge claims, including ethical and practical outcomes. It encourages reflection on how knowledge is used in real‑world contexts and guards against abstract theorising detached from social responsibility.',
    markscheme: ['States that implications reveal consequences of knowledge.', 'Mentions ethical or practical outcomes.', 'Explains that applications connect theory to real life.', 'Emphasises reflection to promote responsible knowledge use.']
  },
  {
    id: 'q59', subject: 'tok', difficulty: 'medium', topic: 'Ethics', marks: 4,
    prompt: 'Discuss how ethical considerations can influence the methods used in scientific research.',
    answer: 'Ethical considerations require researchers to protect participants, minimise harm and obtain informed consent. In human or animal studies this may limit certain experiments, influencing sample sizes, experimental design and data collection. Researchers must balance the pursuit of knowledge with respect for moral principles.',
    markscheme: ['Mentions protection of participants or minimising harm.', 'Discusses informed consent or ethical approval.', 'Explains limitations imposed on methodology (e.g., sample size, design).', 'Notes balancing scientific goals with moral principles.']
  },
  {
    id: 'q60', subject: 'turkish-b', difficulty: 'medium', topic: 'Bireysel ve toplumsal değerler', marks: 4,
    prompt: 'Bir metinde bireysel ve toplumsal değerlerin çatışması nasıl analiz edilir?',
    answer: 'Bu tür analizde önce karakterlerin bireysel arzuları ve toplumsal beklentiler arasındaki gerilim saptanır. Dil ve sembollerin kullanımı, olay örgüsü ve bakış açısı incelenerek bireysel özgürlüklerin toplumsal normlarla nasıl çatıştığı ve bunun anlatıya etkisi ortaya konur.',
    markscheme: ['Bireysel arzular ile toplumsal beklentiler arasındaki gerilime vurgu yapar.', 'Dil, sembol veya bakış açısı gibi unsurları inceler.', 'Çatışmanın anlatıdaki rolünü açıklar.', 'Sonuçta metnin ana mesajına katkısını belirtir.']
  },
  {
    id: 'q61', subject: 'biology', difficulty: 'medium', topic: 'Metabolism', marks: 4,
    prompt: 'Define metabolism and differentiate between anabolism and catabolism, providing one example of each.',
    answer: 'Metabolism is the sum of all chemical reactions occurring in an organism. Anabolism refers to metabolic pathways that build complex molecules from simpler ones, such as the synthesis of proteins from amino acids. Catabolism refers to pathways that break down molecules to release energy, such as the breakdown of glucose during cellular respiration.',
    markscheme: ['Defines metabolism as all chemical reactions in an organism.', 'Defines anabolism as building complex molecules.', 'Provides an anabolic example like protein synthesis or photosynthesis.', 'Defines catabolism as breaking down molecules to release energy with an example like respiration.']
  },
  {
    id: 'q62', subject: 'biology', difficulty: 'medium', topic: 'Homeostasis', marks: 4,
    prompt: 'Explain the concept of homeostasis and describe how negative feedback helps maintain a constant body temperature.',
    answer: 'Homeostasis is the maintenance of a relatively constant internal environment despite external changes. Negative feedback involves receptors detecting deviations from a set point and effectors taking actions to counteract the change. For body temperature, when core temperature rises, mechanisms such as sweating and vasodilation increase heat loss; when it falls, shivering and vasoconstriction generate and conserve heat.',
    markscheme: ['Defines homeostasis.', 'Describes negative feedback as detecting and counteracting deviations.', 'Provides body temperature example with responses to high temperature.', 'Provides responses to low temperature (shivering/vasoconstriction).']
  },
  {
    id: 'q63', subject: 'chemistry', difficulty: 'easy', topic: 'Atomic structure', marks: 3,
    prompt: 'Determine the numbers of protons, neutrons and electrons in the isotope \u00b914C.',
    answer: 'Carbon has atomic number 6, so \u00b914C has 6 protons and, in a neutral atom, 6 electrons. The mass number 14 indicates 14 - 6 = 8 neutrons.',
    markscheme: ['Recognises atomic number of carbon is 6.', 'States protons = 6 and electrons = 6.', 'Calculates neutrons = 14 - 6 = 8.', 'Gives all three numbers correctly.']
  },
  {
    id: 'q64', subject: 'chemistry', difficulty: 'easy', topic: 'Bonding & Structure', marks: 3,
    prompt: 'Describe two differences between ionic and covalent bonds.',
    answer: 'Ionic bonds form between metals and non‑metals by complete transfer of electrons, creating oppositely charged ions that attract in a lattice structure. Covalent bonds occur between non‑metals where atoms share electron pairs to form discrete molecules.',
    markscheme: ['Notes ionic bonding involves transfer of electrons.', 'Identifies bonding between metals and non‑metals for ionic bonds.', 'Notes covalent bonding involves shared electron pairs.', 'Identifies bonding between non‑metals for covalent bonds and formation of molecules.']
  },
  {
    id: 'q65', subject: 'chemistry', difficulty: 'medium', topic: 'Energetics', marks: 4,
    prompt: 'Differentiate between exothermic and endothermic reactions in terms of enthalpy change and provide one example of each.',
    answer: 'Exothermic reactions release heat to the surroundings and have a negative enthalpy change (\u0394H < 0); combustion of methane is an example. Endothermic reactions absorb heat from the surroundings and have a positive enthalpy change (\u0394H > 0); photosynthesis is an example.',
    markscheme: ['States that exothermic reactions release heat and have negative \u0394H.', 'Provides an example of an exothermic reaction such as combustion.', 'States that endothermic reactions absorb heat and have positive \u0394H.', 'Provides an example of an endothermic process such as photosynthesis or thermal decomposition.']
  },
  {
    id: 'q66', subject: 'chemistry', difficulty: 'medium', topic: 'Equilibrium', marks: 4,
    prompt: 'State Le Ch\u00e2telier’s principle and predict the effect of increasing the temperature on the equilibrium position of an exothermic reaction.',
    answer: 'Le Ch\u00e2telier’s principle states that if a dynamic equilibrium is disturbed by a change in conditions, the system adjusts to counteract the change. For an exothermic reaction, raising the temperature adds heat, so the equilibrium shifts to favour the endothermic direction (towards reactants) to absorb the excess heat.',
    markscheme: ['Defines Le Ch\u00e2telier’s principle.', 'Identifies heat as a product in an exothermic reaction.', 'Predicts that increasing temperature shifts equilibrium toward reactants.', 'Explains the rationale that this absorbs the added heat.']
  },
  {
    id: 'q67', subject: 'economics', difficulty: 'medium', topic: 'Macroeconomics', marks: 4,
    prompt: 'Define gross domestic product (GDP) and distinguish between nominal GDP and real GDP.',
    answer: 'Gross domestic product is the total monetary value of all final goods and services produced within a country’s borders in a given period. Nominal GDP is measured using current market prices and does not account for inflation. Real GDP adjusts nominal GDP for changes in the price level, allowing comparison over time.',
    markscheme: ['Defines GDP as total value of final goods and services produced domestically.', 'Explains that nominal GDP uses current prices and ignores inflation.', 'Explains that real GDP adjusts for price changes/inflation.', 'Notes that real GDP allows comparisons over time.']
  },
  {
    id: 'q68', subject: 'business', difficulty: 'medium', topic: 'Finance and accounts', marks: 4,
    prompt: 'Differentiate between profit and cash flow and explain why a profitable business might still face liquidity problems.',
    answer: 'Profit is the surplus of revenue over expenses during an accounting period. Cash flow refers to the actual movement of cash into and out of the business. A firm can be profitable on paper but face liquidity issues if cash inflows are delayed (e.g., customers not paying on time) or if large outlays are required for inventory, leaving insufficient cash to cover immediate obligations.',
    markscheme: ['Defines profit as revenue minus expenses.', 'Defines cash flow as the movement of cash into and out of the business.', 'Explains that timing differences between income and expenditure can cause liquidity problems.', 'Provides an example such as delayed customer payments or high inventory costs.']
  },
  {
    id: 'q69', subject: 'history', difficulty: 'medium', topic: 'Authoritarian states', marks: 4,
    prompt: 'Describe two characteristics of an authoritarian state and give one example of such a state in the 20th century.',
    answer: 'Authoritarian states typically feature concentrated political power in a single party or leader, suppression of political opposition, censorship and propaganda, and limited civil liberties. Examples include Stalin\'s Soviet Union, Nazi Germany under Hitler, or Franco\'s Spain.',
    markscheme: ['Lists two features such as single‑party rule, suppression of dissent, censorship, personality cults or lack of free elections.', 'Explains each characteristic briefly.', 'Provides a historical example such as Stalin\'s USSR or Nazi Germany.', 'Links example to the described characteristics.']
  },
  {
    id: 'q70', subject: 'geography', difficulty: 'medium', topic: 'Population dynamics', marks: 4,
    prompt: 'Explain what is meant by carrying capacity in population ecology and how it affects population growth.',
    answer: 'Carrying capacity is the maximum number of individuals of a species that an environment can sustainably support over time. As a population approaches its carrying capacity, resources become limited and growth slows, producing a logistic (S‑shaped) growth curve. Populations may fluctuate around the carrying capacity due to environmental variability.',
    markscheme: ['Defines carrying capacity as maximum sustainable population size.', 'Describes resource limitation as population approaches this limit.', 'Mentions the logistic growth curve or slowing growth rate.', 'Notes possible fluctuations around carrying capacity due to environmental factors.']
  },
  {
    id: 'q71', subject: 'psychology', difficulty: 'medium', topic: 'Cognitive approach', marks: 4,
    prompt: 'Outline the multi‑store model of memory proposed by Atkinson and Shiffrin.',
    answer: 'The multi‑store model suggests memory consists of three stores: sensory memory, which briefly holds incoming information; short‑term memory, which has limited capacity and duration and can hold information through rehearsal; and long‑term memory, which has potentially unlimited capacity and duration. Information passes sequentially through these stores via attention and rehearsal.',
    markscheme: ['Names sensory, short‑term and long‑term memory stores.', 'Describes the capacity and duration of each store.', 'Mentions the processes of attention and rehearsal for transfer of information.', 'Notes sequential flow from sensory to STM to LTM.']
  },
  {
    id: 'q72', subject: 'visual-arts', difficulty: 'medium', topic: 'Materials and techniques', marks: 4,
    prompt: 'Explain how the choice of artistic medium, such as oil paint versus watercolour, can influence the visual impact of an artwork.',
    answer: 'Oil paints dry slowly and allow rich, opaque colours, blending and layering, which can create depth and texture. Watercolours are transparent and fluid, producing luminous washes and delicate effects. The medium shapes the mood and style of the piece: oils often convey solidity and realism, while watercolours evoke lightness and spontaneity.',
    markscheme: ['Describes properties of oil paint (slow drying, rich colours, blending).', 'Describes properties of watercolour (transparent, fluid, quick drying).', 'Explains how these properties affect texture or mood.', 'Connects medium choice to artistic style or impact.']
  },
  {
    id: 'q73', subject: 'ess', difficulty: 'medium', topic: 'Water and soil', marks: 4,
    prompt: 'Define infiltration and percolation in the hydrological cycle and explain their ecological significance.',
    answer: 'Infiltration is the process by which surface water enters the soil. Percolation is the downward movement of infiltrated water through soil layers into deeper groundwater reserves. These processes recharge aquifers, maintain soil moisture necessary for plant growth, and influence runoff and flood risks.',
    markscheme: ['Defines infiltration as surface water entering the soil.', 'Defines percolation as downward movement of water through soil to groundwater.', 'Mentions recharge of aquifers or maintenance of soil moisture.', 'Explains influence on runoff or flood risks.']
  },
  {
    id: 'q74', subject: 'spanish-b', difficulty: 'easy', topic: 'Reading comprehension', marks: 3,
    prompt: 'Cuando lees un texto en español, ¿por qué es útil identificar las palabras clave y los conectores?',
    answer: 'Identificar las palabras clave y los conectores lógicos (como “sin embargo”, “por lo tanto” o “aunque”) ayuda a captar las ideas principales y la estructura del texto. Estas pistas facilitan la comprensión global y la relación entre los argumentos, especialmente cuando no se comprende cada palabra.',
    markscheme: ['Señala la importancia de identificar palabras clave y conectores.', 'Explica que esto ayuda a entender las ideas principales y la estructura.', 'Menciona conectores lógicos como ejemplos.', 'Indica que esta estrategia mejora la comprensión incluso sin entender todas las palabras.']
  }
];

const flashcards = [
  { id: 'f1', subject: 'math-aa-hl', front: 'What does the Hessian matrix measure?', back: 'It organizes second partial derivatives to describe curvature in a multivariable function.' },
  { id: 'f2', subject: 'physics-hl', front: 'What is electric potential?', back: 'Work done per unit positive charge in bringing a small test charge from infinity to that point.' },
  { id: 'f3', subject: 'cs-hl', front: 'What does ADT mean?', back: 'Abstract Data Type: a definition of behaviour and operations independent of implementation.' },
  { id: 'f4', subject: 'english-a', front: 'What is an authorial choice?', back: 'A deliberate technique such as diction, imagery, structure, voice, or contrast used to create meaning.' },
  { id: 'f5', subject: 'tok', front: 'What is an AOK?', back: 'Area of Knowledge, such as history, natural sciences, human sciences, mathematics, or the arts.' },
  { id: 'f6', subject: 'turkish-b', front: 'IO’da teknik neye bağlanmalı?', back: 'Teknik, anlam ve küresel sorun arasındaki ilişkiye bağlanmalı.' },
  { id: 'f7', subject: 'physics-hl', front: 'In SHM, what happens to total energy if amplitude doubles?', back: 'Total energy is proportional to amplitude squared, so it becomes four times larger.' },
  { id: 'f8', subject: 'cs-hl', front: 'LIFO describes which ADT?', back: 'Stack. The last item pushed is the first item popped.' }
  ,
  // Additional flashcards for newly added subjects to support quick recall of key
  // concepts across the IB curriculum.
  { id: 'f9', subject: 'biology', front: 'Which organelles contain their own DNA besides the nucleus?', back: 'Mitochondria and chloroplasts contain circular DNA separate from nuclear DNA.' },
  { id: 'f10', subject: 'chemistry', front: 'What is Avogadro’s constant?', back: 'Approximately 6.02 × 10^23 mol⁻¹, representing the number of particles in one mole.' },
  { id: 'f11', subject: 'economics', front: 'What does GDP stand for?', back: 'Gross Domestic Product—the total monetary value of all final goods and services produced within a country’s borders in a given period.' },
  { id: 'f12', subject: 'business', front: 'Name the four Ps of the marketing mix.', back: 'Product, Price, Place, and Promotion.' },
  { id: 'f13', subject: 'history', front: 'In what year did the Second World War end?', back: '1945 (in Europe May 8; formal surrender September 2).' },
  { id: 'f14', subject: 'geography', front: 'What is the greenhouse effect?', back: 'The warming of Earth’s surface due to greenhouse gases absorbing and re‑emitting infrared radiation.' },
  { id: 'f15', subject: 'psychology', front: 'What is classical conditioning?', back: 'A learning process in which a neutral stimulus becomes associated with a response through repeated pairing with an unconditioned stimulus.' },
  { id: 'f16', subject: 'visual-arts', front: 'Define chiaroscuro.', back: 'The dramatic use of strong contrasts between light and dark to model three‑dimensional form and create atmosphere.' },
  { id: 'f17', subject: 'ess', front: 'What is a keystone species?', back: 'A species that plays a critical role in maintaining the structure of an ecological community and whose removal would cause drastic changes.' },
  { id: 'f18', subject: 'spanish-b', front: 'How do you say “thank you” in Spanish?', back: 'Gracias.' }
];

const uid = () => (globalThis.crypto?.randomUUID ? globalThis.crypto.randomUUID() : `id-${Date.now()}-${Math.random().toString(16).slice(2)}`);

const defaultTasks = [
  { id: uid(), title: 'Finish 10 Physics waves questions', subject: 'Physics HL', done: false },
  { id: uid(), title: 'Rewrite one IA evaluation paragraph', subject: 'Math IA', done: false },
  { id: uid(), title: 'Review ADT operations and edge cases', subject: 'CS HL', done: false }
];

const storeKey = 'openib-forge-v1';

// Remote storage configuration
//
// The website supports syncing your progress to an online database so that
// progress persists across devices. We use Supabase for this: a free hosted
// Postgres database with a RESTful API. To connect to your Supabase project,
// supply the URL of your project and the public anon key below. These values
// are obtained from the Supabase dashboard under Settings → API. Without
// setting these values the app will operate entirely in the browser using
// localStorage.

// URL of your Supabase project (e.g. https://your-project-id.supabase.co)
const SUPABASE_URL = 'https://dfkvpeyittwljckwghkr.supabase.co';
// Public API key (anon) for your Supabase project. This key is safe to use in
// client-side code and allows reading and writing to tables with Row Level
// Security disabled or appropriate policies. Do NOT use the service_role key.
const SUPABASE_ANON_KEY = 'sb_publishable_R5gljMTkm-ZFGG7nzEbmmQ_gnYanrC1';

// Because this app is served directly from the filesystem (file://) when
// developed locally, we avoid importing external modules. Instead of using
// the @supabase/supabase-js client library we interact with Supabase via
// direct HTTP calls to the autogenerated REST API. These headers are
// required for all requests: the apikey authenticates the client and
// Authorization is the same key again (as a bearer token). See
// https://supabase.com/docs/guides/api#auth for details.
const supabaseHeaders = SUPABASE_URL && SUPABASE_ANON_KEY ? {
  apikey: SUPABASE_ANON_KEY,
  Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
  'Content-Type': 'application/json'
} : null;

/**
 * Fetch the latest state from the remote JSON storage. If successful, the
 * returned value will be merged with the current state and UI will update.
 * If remote configuration is missing or the request fails, nothing happens.
 */
async function loadRemoteState() {
  // If Supabase is not configured, fall back to local only
  if (!SUPABASE_URL || !SUPABASE_ANON_KEY || !supabaseHeaders) return;
  try {
    // Fetch the row with id=1 from the state table. The `select=data` query
    // tells PostgREST to return only the "data" column. When no row exists
    // the response will be an empty array.
    // Use the logged-in user ID as the row key; fall back to 1 for demo/default state
    const rowId = currentUserId || 1;
    const url = `${SUPABASE_URL}/rest/v1/state?id=eq.${rowId}&select=data`;
    const res = await fetch(url, { headers: supabaseHeaders });
    if (!res.ok) {
      console.warn('Supabase load state request failed', res.status);
      return;
    }
    const rows = await res.json();
    if (Array.isArray(rows) && rows.length > 0 && rows[0].data && typeof rows[0].data === 'object') {
      state = Object.assign({}, state, rows[0].data);
      localStorage.setItem(storeKey, JSON.stringify(state));
      renderAll();
    }
  } catch (err) {
    console.error('Failed to load remote state', err);
  }
}

/**
 * Push the current state to the remote JSON storage. If remote configuration is
 * missing, this function silently does nothing. Errors are logged but do not
 * interrupt the user experience.
 */
async function syncStateToRemote() {
  if (!SUPABASE_URL || !SUPABASE_ANON_KEY || !supabaseHeaders) return;
  try {
    // Use upsert via PostgREST by sending an array of records and setting
    // `Prefer: resolution=merge-duplicates` so that conflicts on primary key
    // cause an update rather than error. When the row does not exist the
    // record will be inserted. We keep return=minimal to reduce bandwidth.
    const rowId = currentUserId || 1;
    const url = `${SUPABASE_URL}/rest/v1/state`;
    await fetch(url, {
      method: 'POST',
      headers: { ...supabaseHeaders, Prefer: 'resolution=merge-duplicates,return=minimal' },
      body: JSON.stringify([{ id: rowId, data: state }])
    });
  } catch (err) {
    console.error('Failed to sync state to remote', err);
  }
}

/**
 * Load the authenticated user's profile from the profiles table. When a row exists,
 * its exam_session, weekly_hours and target_grade fields are copied into the
 * state.profile object. When no row exists, state.profile is reset to defaults.
 */
async function loadUserProfile() {
  if (!SUPABASE_URL || !supabaseHeaders || !currentUserId) return;
  try {
    const url = `${SUPABASE_URL}/rest/v1/profiles?select=exam_session,weekly_hours,target_grade&user_id=eq.${currentUserId}`;
    const res = await fetch(url, { headers: supabaseHeaders });
    if (!res.ok) return;
    const rows = await res.json();
    if (Array.isArray(rows) && rows.length > 0) {
      state.profile = {
        exam_session: rows[0].exam_session || '',
        weekly_hours: rows[0].weekly_hours || 0,
        target_grade: rows[0].target_grade || 0
      };
    } else {
      state.profile = { exam_session: '', weekly_hours: 0, target_grade: 0 };
    }
  } catch (err) {
    console.error('Failed to load user profile', err);
  }
}

/**
 * Save or update the authenticated user's profile. Uses an upsert so that if
 * the row exists it is updated; otherwise it is inserted. Requires RLS
 * policies on the profiles table to permit the logged-in user.
 */
async function saveUserProfile(profile) {
  if (!SUPABASE_URL || !supabaseHeaders || !currentUserId) return;
  try {
    const url = `${SUPABASE_URL}/rest/v1/profiles`;
    const body = [{ user_id: currentUserId, exam_session: profile.exam_session, weekly_hours: profile.weekly_hours, target_grade: profile.target_grade }];
    await fetch(url, {
      method: 'POST',
      headers: { ...supabaseHeaders, Prefer: 'resolution=merge-duplicates,return=minimal' },
      body: JSON.stringify(body)
    });
  } catch (err) {
    console.error('Failed to save user profile', err);
  }
}

// Helper to show the profile setup modal. It populates input fields with the current
// state.profile values (if any) and reveals the modal. Called after login when
// profile fields are empty.
function showProfileModal() {
  const modal = document.getElementById('profileModal');
  if (!modal) return;
  // Set initial values on inputs
  const es = document.getElementById('examSessionInput');
  const wh = document.getElementById('weeklyHoursInput');
  const tg = document.getElementById('targetGradeInput');
  if (es) es.value = state.profile?.exam_session || '';
  if (wh) wh.value = state.profile?.weekly_hours || '';
  if (tg) tg.value = state.profile?.target_grade || '';
  modal.classList.remove('hidden');
}
// Logged-in user ID. This will be set after successful authentication.
let currentUserId = null;

let state = loadState();
let currentCard = null;
let showingBack = false;
let timerId = null;
let secondsLeft = 25 * 60;
// Additional Pomodoro configuration values. These can be changed by the user
// via the input fields in the planner view. sessionLength sets the length
// of a work session in minutes and breakLength sets the length of the break.
let sessionLength = 25;
let breakLength = 5;
let isBreak = false;

function loadState() {
  const saved = localStorage.getItem(storeKey);
  if (saved) {
    try { return JSON.parse(saved); } catch { /* fall through */ }
  }
  return {
    questions: {},
    flashcards: {},
    tasks: defaultTasks,
    chat: [{ role: 'bot', text: 'Ask me a specific IB question. I will answer step by step and keep it revision-focused.' }],
    reviews: []
    ,
    preferences: {
      subjects: []
    }
    ,
    // User profile information collected during onboarding. exam_session identifies the exam
    // sitting (e.g. "May 2026"), weekly_hours is a number of study hours per week, and
    // target_grade is the desired average grade on a 1–7 scale. These values are used to
    // personalize study plans and can be updated later by the user.
    profile: {
      exam_session: '',
      weekly_hours: 0,
      target_grade: 0
    }
  };
}

function saveState() {
  // Persist locally
  localStorage.setItem(storeKey, JSON.stringify(state));
  // Also push to remote asynchronously. The Promise is not awaited to avoid
  // blocking the UI. Errors will be logged but not surfaced to the user.
  syncStateToRemote();
}
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const subjectName = (id) => subjects.find(s => s.id === id)?.name || id;
const escapeHTML = (str = '') => str.replace(/[&<>'"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[c]));

function toast(message) {
  const el = $('#toast');
  el.textContent = message;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 2400);
}

// Supabase authentication helpers
/**
 * Sign up a new user using Supabase Auth.
 * @param {string} email
 * @param {string} password
 * @returns {Promise<{user:any,error:any}>}
 */
async function supabaseSignup(email, password) {
  try {
    const res = await fetch(`${SUPABASE_URL}/auth/v1/signup`, {
      method: 'POST',
      headers: { apikey: SUPABASE_ANON_KEY, 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (!res.ok) return { user: null, error: new Error(data.msg || data.error_description || data.message || 'Sign up failed') };
    return { user: data.user, error: null };
  } catch (err) {
    return { user: null, error: err };
  }
}

/**
 * Log in an existing user. Returns the user and access token.
 * @param {string} email
 * @param {string} password
 * @returns {Promise<{user:any, access_token:string, error:any}>}
 */
async function supabaseLogin(email, password) {
  try {
    const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
      method: 'POST',
      headers: { apikey: SUPABASE_ANON_KEY, 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (!res.ok) return { user: null, access_token: null, error: new Error(data.msg || data.error_description || data.message || 'Login failed') };
    return { user: data.user || data, access_token: data.access_token, error: null };
  } catch (err) {
    return { user: null, access_token: null, error: err };
  }
}

function setView(viewId) {
  $$('.view').forEach(v => v.classList.toggle('active', v.id === viewId));
  $$('.nav-item').forEach(btn => btn.classList.toggle('active', btn.dataset.view === viewId));
  $('.sidebar').classList.remove('open');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function populateSelects() {
  const subjectOptions = '<option value="all">All subjects</option>' + subjects.map(s => `<option value="${s.id}">${s.name} ${s.level}</option>`).join('');
  ['#questionSubjectFilter', '#notesSubjectFilter', '#flashcardSubjectFilter'].forEach(id => $(id).innerHTML = subjectOptions);
  $('#tutorSubject').innerHTML = subjects.map(s => `<option value="${s.id}">${s.name} ${s.level}</option>`).join('');
  $('#examSubject').innerHTML = subjects.map(s => `<option value="${s.id}">${s.name} ${s.level}</option>`).join('');
}

function renderStats() {
  const doneQuestions = Object.values(state.questions).filter(Boolean).length;
  const completedTasks = state.tasks.filter(t => t.done).length;
  const knownCards = Object.values(state.flashcards).filter(v => v?.known).length;
  const totalUnits = questions.length + state.tasks.length + flashcards.length;
  const totalDone = doneQuestions + completedTasks + knownCards;
  const percent = Math.round((totalDone / Math.max(totalUnits, 1)) * 100);
  $('#overallScore').textContent = `${percent}%`;
  $('#sideProgress').style.width = `${percent}%`;
  $('#todayGoal').textContent = completedTasks >= 3 ? 'Goal complete' : `${Math.max(0, 3 - completedTasks)} tasks left`;
  $('#statGrid').innerHTML = [
    ['Questions done', `${doneQuestions}/${questions.length}`, 'Markscheme practice completed'],
    ['Cards learned', `${knownCards}/${flashcards.length}`, 'Active recall progress'],
    ['Tasks complete', `${completedTasks}/${state.tasks.length}`, 'Today’s study execution']
  ].map(([title, value, sub]) => `<article class="panel stat-card"><span>${title}</span><strong>${value}</strong><p class="muted">${sub}</p></article>`).join('');
}

function renderRecommendations() {
  const unfinished = questions.filter(q => !state.questions[q.id]).slice(0, 3);
  const tasks = state.tasks.filter(t => !t.done).slice(0, 2);
  const items = [
    ...unfinished.map(q => ({ title: `Practise ${q.topic}`, sub: `${subjectName(q.subject)} · ${q.marks} marks`, view: 'questions' })),
    ...tasks.map(t => ({ title: t.title, sub: t.subject, view: 'planner' }))
  ].slice(0, 5);
  $('#recommendations').innerHTML = items.map(item => `
    <article class="card">
      <strong>${escapeHTML(item.title)}</strong>
      <p class="muted">${escapeHTML(item.sub)}</p>
      <button class="chip" data-view-jump="${item.view}">Open</button>
    </article>`).join('') || '<p class="muted">Everything is complete. Add more tasks or questions.</p>';

  const bySubject = questions.reduce((acc, q) => {
    acc[q.subject] ||= { total: 0, done: 0 };
    acc[q.subject].total++;
    if (state.questions[q.id]) acc[q.subject].done++;
    return acc;
  }, {});
  const weak = Object.entries(bySubject).sort((a, b) => (a[1].done / a[1].total) - (b[1].done / b[1].total)).slice(0, 4);
  $('#weakAreas').innerHTML = weak.map(([id, data]) => {
    const pct = Math.round((data.done / data.total) * 100);
    return `<article class="card"><strong>${subjectName(id)}</strong><p class="muted">${pct}% completed</p><div class="progress-track"><span style="width:${pct}%"></span></div></article>`;
  }).join('');
}

function renderSubjects() {
  const level = $('#levelFilter').value;
  const filtered = subjects.filter(s => level === 'all' || s.level.includes(level));
  $('#subjectGrid').innerHTML = filtered.map(s => {
    const subjectQuestions = questions.filter(q => q.subject === s.id);
    const done = subjectQuestions.filter(q => state.questions[q.id]).length;
    const pct = subjectQuestions.length ? Math.round(done / subjectQuestions.length * 100) : 0;
    // Show a checkbox for logged‑in users to mark the subject as one of their courses
    let selectorHtml = '';
    if (currentUserId) {
      const selected = state.preferences?.subjects?.includes(s.id);
      selectorHtml = `<label class="subject-select"><input type="checkbox" data-select-subject="${s.id}"${selected ? ' checked' : ''}> Take this subject</label>`;
    }
    return `<article class="panel card subject-card">
      <span class="tag">${escapeHTML(s.level)}</span>
      <h2>${s.icon} ${escapeHTML(s.name)}</h2>
      <p class="muted">${escapeHTML(s.description)}</p>
      <div class="subject-meta">
        <span class="tag">${subjectQuestions.length} questions</span>
        <span class="tag">${pct}% done</span>
      </div>
      <div class="progress-track"><span style="width:${pct}%"></span></div>
      ${selectorHtml}
      <ul class="topic-list">${s.topics.map(t => `<li><span>${escapeHTML(t)}</span><small>revise</small></li>`).join('')}</ul>
    </article>`;
  }).join('');
}

function renderQuestions() {
  const subject = $('#questionSubjectFilter').value;
  const difficulty = $('#difficultyFilter').value;
  const search = $('#globalSearch').value.toLowerCase().trim();
  const filtered = questions.filter(q =>
    (subject === 'all' || q.subject === subject) &&
    (difficulty === 'all' || q.difficulty === difficulty) &&
    (!search || `${q.prompt} ${q.topic} ${q.answer} ${subjectName(q.subject)}`.toLowerCase().includes(search))
  );
  // Sort by topic name to group similar concepts together. If topics are identical,
  // preserve their original order. localeCompare ensures case‑insensitive sorting.
  const sorted = filtered.slice().sort((a, b) => a.topic.localeCompare(b.topic));
  // Build the HTML by grouping questions under topic headings. When a new topic
  // appears in the sorted list, insert a heading before the first question of
  // that topic. This improves organisation and makes the question bank easier
  // to scan. Keep the existing card structure for each question.
  let html = '';
  sorted.forEach((q, idx) => {
    if (idx === 0 || sorted[idx - 1].topic !== q.topic) {
      html += `<h3 class="topic-heading">${escapeHTML(q.topic)}</h3>`;
    }
    html += `
      <article class="question-card" data-question-id="${q.id}">
        <div class="panel-heading">
          <div>
            <span class="tag">${subjectName(q.subject)} · ${escapeHTML(q.topic)}</span>
            <h2>${escapeHTML(q.prompt)}</h2>
          </div>
          <span class="score-pill">${q.marks} marks</span>
        </div>
        <details>
          <summary>Show answer and markscheme</summary>
          <p>${escapeHTML(q.answer)}</p>
          <strong>Markscheme points</strong>
          <ul>${q.markscheme.map(m => `<li>${escapeHTML(m)}</li>`).join('')}</ul>
        </details>
        <div class="question-actions">
          <span class="difficulty-${q.difficulty.toLowerCase()}">Difficulty: ${q.difficulty}</span>
          <button class="${state.questions[q.id] ? 'secondary' : 'primary'}" data-complete-question="${q.id}">${state.questions[q.id] ? 'Completed' : 'Mark complete'}</button>
        </div>
      </article>`;
  });
  $('#questionList').innerHTML = html || '<p class="muted">No questions match your filters.</p>';
}

function renderNotes() {
  const subject = $('#notesSubjectFilter').value;
  const search = $('#globalSearch').value.toLowerCase().trim();
  const filtered = notes.filter(n =>
    (subject === 'all' || n.subject === subject) &&
    (!search || `${n.title} ${n.summary} ${n.bullets.join(' ')}`.toLowerCase().includes(search))
  );
  $('#notesList').innerHTML = filtered.map(n => `
    <article class="note-card">
      <span class="tag">${subjectName(n.subject)}</span>
      <h2>${escapeHTML(n.title)}</h2>
      <p class="muted">${escapeHTML(n.summary)}</p>
      <ul>${n.bullets.map(b => `<li>${escapeHTML(b)}</li>`).join('')}</ul>
    </article>`).join('') || '<p class="muted">No notes match your filters.</p>';
}

function getDueFlashcards() {
  const subject = $('#flashcardSubjectFilter').value;
  const now = Date.now();
  return flashcards.filter(card => {
    const progress = state.flashcards[card.id];
    return (subject === 'all' || card.subject === subject) && (!progress?.nextDue || progress.nextDue <= now);
  });
}

function showCard(card) {
  currentCard = card;
  showingBack = false;
  $('#flashcardTag').textContent = card ? subjectName(card.subject) : 'No cards';
  $('#flashcardText').textContent = card ? card.front : 'No due flashcards for this filter.';
  $('#flashcardHint').textContent = card ? 'Click the card to flip.' : 'Change subject or reset progress to see more.';
}

function renderFlashcardCounts() {
  if (!currentCard) showCard(getDueFlashcards()[0] || flashcards[0]);
}

function nextFlashcard() {
  const due = getDueFlashcards();
  const pool = due.length ? due : flashcards.filter(c => $('#flashcardSubjectFilter').value === 'all' || c.subject === $('#flashcardSubjectFilter').value);
  showCard(pool[Math.floor(Math.random() * pool.length)] || null);
}

function gradeFlashcard(known) {
  if (!currentCard) return;
  const interval = known ? 3 * 24 * 60 * 60 * 1000 : 2 * 60 * 60 * 1000;
  state.flashcards[currentCard.id] = { known, nextDue: Date.now() + interval };
  saveState();
  renderStats();
  nextFlashcard();
}

function renderTasks() {
  $('#taskList').innerHTML = state.tasks.map(t => `
    <article class="task ${t.done ? 'done' : ''}">
      <input type="checkbox" ${t.done ? 'checked' : ''} data-task-toggle="${t.id}" />
      <div><strong>${escapeHTML(t.title)}</strong><p class="muted">${escapeHTML(t.subject)}</p></div>
      <button class="ghost danger" data-task-delete="${t.id}">Delete</button>
    </article>`).join('') || '<p class="muted">No tasks yet.</p>';
}

function renderChat() {
  $('#chatLog').innerHTML = state.chat.map(m => `<div class="message ${m.role === 'user' ? 'user' : 'bot'}">${escapeHTML(m.text)}</div>`).join('');
  $('#chatLog').scrollTop = $('#chatLog').scrollHeight;
}

function buildExam() {
  const subject = $('#examSubject').value;
  const difficulty = $('#examDifficulty').value;
  const count = Number($('#examCount').value) || 5;
  const pool = questions.filter(q => q.subject === subject && (difficulty === 'all' || q.difficulty === difficulty));
  const picked = [...pool].sort(() => Math.random() - .5).slice(0, count);
  $('#examPreview').innerHTML = `
    <h2>${subjectName(subject)} practice exam</h2>
    <p class="muted">Generated from your local free question bank. Add more questions inside app.js to expand it.</p>
    ${picked.map((q, i) => `<article class="question-card"><span class="tag">Question ${i + 1} · ${q.marks} marks</span><h3>${escapeHTML(q.prompt)}</h3><p class="muted">Topic: ${escapeHTML(q.topic)} · Difficulty: ${q.difficulty}</p></article>`).join('') || '<p class="muted">No questions available for this combination.</p>'}
    <h2>Answer key</h2>
    ${picked.map((q, i) => `<details><summary>Answer ${i + 1}</summary><p>${escapeHTML(q.answer)}</p><ul>${q.markscheme.map(m => `<li>${escapeHTML(m)}</li>`).join('')}</ul></details>`).join('')}
  `;
}

function renderAll() {
  renderStats();
  renderRecommendations();
  renderSubjects();
  renderQuestions();
  renderNotes();
  renderFlashcardCounts();
  renderTasks();
  renderChat();
}

function localCourseworkReview({ type, focus, text }) {
  const words = text.trim().split(/\s+/).filter(Boolean);
  const paragraphs = text.split(/\n\s*\n/).filter(p => p.trim().length > 30);
  const lower = text.toLowerCase();
  const checks = {
    researchQuestion: /research question|rq|to what extent|how does|what is the effect/i.test(text),
    data: /data|table|graph|trend|correlation|uncertainty|error|standard deviation|mean|gradient/i.test(text),
    evaluation: /limitation|evaluate|improve|weakness|assumption|validity|reliability|error/i.test(text),
    citations: /\([A-Z][A-Za-z]+,?\s?\d{4}\)|works cited|bibliography|reference|citation/i.test(text),
    personal: /i chose|i was interested|my investigation|personally|real life|relevant/i.test(lower),
    structure: paragraphs.length >= 4,
    analysis: /therefore|this shows|suggests|because|as a result|indicates|implies/i.test(lower)
  };
  const score = Object.values(checks).filter(Boolean).length;
  const readiness = Math.round((score / Object.keys(checks).length) * 100);

  const typeTips = {
    'Math IA': ['Make the mathematical aim visible early.', 'Explain why each method is needed, not only how it works.', 'Add reflection after calculations, especially when a result affects the model.'],
    'Physics IA': ['State independent, dependent, and controlled variables clearly.', 'Include uncertainty propagation or explain uncertainty impact.', 'Evaluation should connect limitations to the reliability of the conclusion.'],
    'Computer Science IA': ['Link every success criterion to a visible test.', 'Show complex techniques with exact code evidence.', 'Evaluation should use client feedback and criteria results.'],
    'English A Essay': ['Move from device naming to effect on meaning.', 'Use short embedded quotations.', 'Keep the thesis arguable and text-specific.'],
    'Extended Essay': ['Make the research question narrow enough for deep analysis.', 'Show source evaluation, not only source use.', 'Use the conclusion to answer the question directly.'],
    'TOK Essay': ['Make the AOK methods explicit.', 'Use examples to test the title.', 'Give a real counterclaim and judge its strength.'],
    'TOK Exhibition': ['Connect each object directly to the prompt.', 'Explain real-world context.', 'Avoid generic object descriptions.']
  };

  const missing = Object.entries(checks).filter(([, ok]) => !ok).map(([key]) => key);
  const focusAdvice = {
    all: 'The draft needs a balanced revision across structure, evidence, analysis, and evaluation.',
    structure: 'Prioritize clearer headings, paragraph sequencing, and signposting between method, analysis, and evaluation.',
    analysis: 'After every result or quotation, add a sentence explaining what it proves and why it matters.',
    methodology: 'Make criteria alignment explicit: aim, method, evidence, uncertainty/limitations, and final judgment.',
    language: 'Shorten long sentences and replace vague claims with precise subject-specific wording.'
  }[focus];

  const strengths = [];
  if (checks.structure) strengths.push('The draft has enough paragraph separation to support a clear structure.');
  if (checks.analysis) strengths.push('There are analytical connectives showing attempts to explain significance.');
  if (checks.evaluation) strengths.push('There is evidence of evaluation or limitation awareness.');
  if (checks.data) strengths.push('The draft appears to include data/results/methodological vocabulary.');
  if (!strengths.length) strengths.push('The draft has enough raw material to start targeted revision, but the assessment logic needs to become clearer.');

  const nextActions = [
    missing.includes('researchQuestion') ? 'Add or sharpen the research question in the introduction.' : 'Check that your research question is repeated or answered in the conclusion.',
    missing.includes('evaluation') ? 'Add a limitation paragraph explaining impact and a realistic improvement.' : 'Make each limitation specific: what it affects, how much, and how you would improve it.',
    missing.includes('data') ? 'Add direct discussion of results, graphs, tables, uncertainties, or textual evidence.' : 'After each piece of data/evidence, explain the trend and significance.',
    missing.includes('citations') ? 'Add citations or a Works Cited / bibliography where required.' : 'Check that every borrowed idea, data source, or quotation is cited consistently.'
  ];

  return `
    <div class="report-section">
      <span class="score-pill">Readiness score: ${readiness}%</span>
      <p class="muted">This is not an official IB grade. It is a revision-readiness estimate based on structure, evidence, analysis, and evaluation signals.</p>
    </div>
    <div class="report-section">
      <h3>Detected strengths</h3>
      <ul>${strengths.map(s => `<li>${escapeHTML(s)}</li>`).join('')}</ul>
    </div>
    <div class="report-section">
      <h3>Priority feedback</h3>
      <p>${escapeHTML(focusAdvice)}</p>
      <ul>${(typeTips[type] || typeTips['Extended Essay']).map(t => `<li>${escapeHTML(t)}</li>`).join('')}</ul>
    </div>
    <div class="report-section">
      <h3>Concrete next edits</h3>
      <ul>${nextActions.map(a => `<li>${escapeHTML(a)}</li>`).join('')}</ul>
    </div>
    <div class="report-section">
      <h3>Basic diagnostics</h3>
      <ul>
        <li>Word count pasted: ${words.length}</li>
        <li>Paragraph-like sections: ${paragraphs.length}</li>
        <li>Research question signal: ${checks.researchQuestion ? 'yes' : 'no'}</li>
        <li>Evaluation signal: ${checks.evaluation ? 'yes' : 'no'}</li>
        <li>Citation signal: ${checks.citations ? 'yes' : 'no'}</li>
      </ul>
    </div>
  `;
}

async function getAIReview(payload) {
  const res = await fetch('/.netlify/functions/ia-review', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  if (!res.ok) throw new Error('AI function unavailable');
  const data = await res.json();
  return data.html || markdownToHtml(data.feedback || 'No feedback returned.');
}

async function getAITutorAnswer(payload) {
  const res = await fetch('/.netlify/functions/ai-tutor', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
  });
  if (!res.ok) throw new Error('AI tutor unavailable');
  const data = await res.json();
  return data.answer;
}

function markdownToHtml(markdown) {
  const lines = markdown.split('\n');
  let html = '';
  let inList = false;
  for (const raw of lines) {
    const line = raw.trim();
    if (!line) continue;
    if (/^#{1,3}\s/.test(line)) {
      if (inList) { html += '</ul>'; inList = false; }
      html += `<div class="report-section"><h3>${escapeHTML(line.replace(/^#{1,3}\s/, ''))}</h3></div>`;
    } else if (/^[-*]\s/.test(line)) {
      if (!inList) { html += '<ul>'; inList = true; }
      html += `<li>${escapeHTML(line.replace(/^[-*]\s/, ''))}</li>`;
    } else {
      if (inList) { html += '</ul>'; inList = false; }
      html += `<p>${escapeHTML(line)}</p>`;
    }
  }
  if (inList) html += '</ul>';
  return html;
}

function localTutorAnswer(question, subjectId) {
  const s = subjectName(subjectId);
  const q = question.toLowerCase();
  const matchingNote = notes.find(n => n.subject === subjectId && n.bullets.concat(n.title, n.summary).join(' ').toLowerCase().split(' ').some(word => word.length > 5 && q.includes(word)));
  if (matchingNote) {
    return `For ${s}, start with this idea: ${matchingNote.summary}\n\nStep 1: define the key term clearly.\nStep 2: apply it to the specific question rather than writing a memorized explanation.\nStep 3: finish with why it matters for marks.\n\nUseful points: ${matchingNote.bullets.slice(0, 3).join(' ')}`;
  }
  if (q.includes('explain') || q.includes('why')) {
    return `For ${s}, use this exam-answer structure:\n\n1. Define the concept in one sentence.\n2. State the mechanism or process.\n3. Apply it directly to the data, text, or scenario in the question.\n4. End with the final consequence.\n\nSend the exact question and I can break it down more precisely.`;
  }
  return `For ${s}, I would solve it by first identifying the topic, listing the known information, choosing the relevant rule/formula/technique, then writing the answer in markscheme-style steps. Paste the exact question for a more detailed walkthrough.`;
}

function wireEvents() {
  $$('.nav-item').forEach(btn => btn.addEventListener('click', () => setView(btn.dataset.view)));
  document.body.addEventListener('click', (e) => {
    const jump = e.target.closest('[data-view-jump]');
    if (jump) setView(jump.dataset.viewJump);
    const complete = e.target.closest('[data-complete-question]');
    if (complete) {
      const id = complete.dataset.completeQuestion;
      state.questions[id] = !state.questions[id];
      saveState(); renderAll();
    }
    const taskToggle = e.target.closest('[data-task-toggle]');
    if (taskToggle) {
      const task = state.tasks.find(t => t.id === taskToggle.dataset.taskToggle);
      if (task) task.done = taskToggle.checked;
      saveState(); renderAll();
    }
    const taskDelete = e.target.closest('[data-task-delete]');
    if (taskDelete) {
      state.tasks = state.tasks.filter(t => t.id !== taskDelete.dataset.taskDelete);
      saveState(); renderAll(); toast('Task deleted');
    }
  });

  $('#menuToggle').addEventListener('click', () => $('.sidebar').classList.toggle('open'));
  $('#focusToggle').addEventListener('click', () => document.body.classList.toggle('focus'));
  $('#resetDemo').addEventListener('click', () => {
    if (confirm('Reset all local demo progress?')) {
      localStorage.removeItem(storeKey);
      state = loadState();
      renderAll();
      toast('Demo data reset');
    }
  });
  $('#globalSearch').addEventListener('input', () => { renderQuestions(); renderNotes(); });
  $('#levelFilter').addEventListener('change', renderSubjects);
  $('#questionSubjectFilter').addEventListener('change', renderQuestions);
  $('#difficultyFilter').addEventListener('change', renderQuestions);
  $('#notesSubjectFilter').addEventListener('change', renderNotes);
  $('#flashcardSubjectFilter').addEventListener('change', () => { currentCard = null; renderFlashcardCounts(); });
  $('#startFlashcards').addEventListener('click', nextFlashcard);
  $('#flashcard').addEventListener('click', () => {
    if (!currentCard) return;
    showingBack = !showingBack;
    $('#flashcardText').textContent = showingBack ? currentCard.back : currentCard.front;
    $('#flashcardHint').textContent = showingBack ? 'Decide if you knew it.' : 'Click the card to flip.';
  });
  $('#againCard').addEventListener('click', () => gradeFlashcard(false));
  $('#knowCard').addEventListener('click', () => gradeFlashcard(true));

  $('#draftFile').addEventListener('change', async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    $('#draftText').value = await file.text();
    toast('Draft loaded');
  });

  $('#reviewForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const payload = { type: $('#workType').value, focus: $('#reviewFocus').value, text: $('#draftText').value.trim() };
    if (payload.text.length < 100) { toast('Paste at least 100 characters.'); return; }
    $('#reviewStatus').textContent = 'Reviewing... using AI if configured, otherwise local rubric engine.';
    $('#reviewReport').innerHTML = '';
    try {
      const html = await getAIReview(payload);
      $('#reviewReport').innerHTML = html;
      $('#reviewStatus').textContent = 'AI review completed.';
    } catch {
      $('#reviewReport').innerHTML = localCourseworkReview(payload);
      $('#reviewStatus').textContent = 'Local rubric review completed. Add OPENAI_API_KEY on Netlify to enable deeper AI feedback.';
    }
  });
  $('#copyReview').addEventListener('click', async () => {
    await navigator.clipboard.writeText($('#reviewReport').innerText || '');
    toast('Review copied');
  });

  $('#chatForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const input = $('#chatInput');
    const question = input.value.trim();
    if (!question) return;
    input.value = '';
    const subject = $('#tutorSubject').value;
    state.chat.push({ role: 'user', text: question });
    state.chat.push({ role: 'bot', text: 'Thinking...' });
    renderChat();
    try {
      const answer = await getAITutorAnswer({ question, subject: subjectName(subject), context: notes.filter(n => n.subject === subject).map(n => `${n.title}: ${n.summary}`).join('\n') });
      state.chat[state.chat.length - 1] = { role: 'bot', text: answer };
    } catch {
      state.chat[state.chat.length - 1] = { role: 'bot', text: localTutorAnswer(question, subject) };
    }
    saveState(); renderChat();
  });

  $('#addTask').addEventListener('click', () => {
    const title = prompt('Task title');
    if (!title) return;
    const subject = prompt('Subject / category', 'IB revision') || 'IB revision';
    state.tasks.push({ id: uid(), title, subject, done: false });
    saveState(); renderAll();
  });

  $('#timerStart').addEventListener('click', () => {
    if (timerId) { clearInterval(timerId); timerId = null; $('#timerStart').textContent = 'Start'; return; }
    $('#timerStart').textContent = 'Pause';
    timerId = setInterval(() => {
      secondsLeft = Math.max(0, secondsLeft - 1);
      updateTimer();
      if (secondsLeft === 0) { clearInterval(timerId); timerId = null; $('#timerStart').textContent = 'Start'; toast('Pomodoro complete'); }
    }, 1000);
  });
  $('#timerReset').addEventListener('click', () => {
    clearInterval(timerId);
    timerId = null;
    // Reset the timer to the configured session length (work period). The user may
    // have changed sessionLength via the input. This ensures the timer reflects
    // their chosen duration. A break will not auto-start; for now resets always
    // return to a work session.
    secondsLeft = sessionLength * 60;
    $('#timerStart').textContent = 'Start';
    updateTimer();
  });
  $('#buildExam').addEventListener('click', buildExam);
  $('#printExam').addEventListener('click', () => window.print());
  $('#generatePlanBtn').addEventListener('click', () => {
    state.tasks.push(
      { id: uid(), title: 'Do one weak-topic question and write why each mark is awarded', subject: 'Question Bank', done: false },
      { id: uid(), title: 'Review one IA paragraph using the coursework tool', subject: 'Coursework', done: false }
    );
    saveState(); renderAll(); toast('Plan added');
  });

  // When a user selects or deselects a subject, update their preferences
  document.body.addEventListener('change', (e) => {
    const target = e.target;
    if (target && target.matches('input[data-select-subject]')) {
      const subjectId = target.getAttribute('data-select-subject');
      if (!state.preferences.subjects) state.preferences.subjects = [];
      if (target.checked) {
        if (!state.preferences.subjects.includes(subjectId)) {
          state.preferences.subjects.push(subjectId);
        }
      } else {
        state.preferences.subjects = state.preferences.subjects.filter(s => s !== subjectId);
      }
      saveState();
      renderSubjects();
    }
    // If the user adjusts the Pomodoro durations, update our variables. We do not
    // immediately reset the timer to avoid disrupting an active session, but the
    // new values will be used on the next reset/start.
    if (target && target.id === 'sessionLength') {
      const v = parseInt(target.value, 10);
      if (!isNaN(v) && v >= 5 && v <= 90) sessionLength = v;
    }
    if (target && target.id === 'breakLength') {
      const v = parseInt(target.value, 10);
      if (!isNaN(v) && v >= 1 && v <= 30) breakLength = v;
    }
  });

  // Global click handler for authentication trigger to ensure the modal opens even if
  // the dedicated event on the button fails to attach. This uses event delegation
  // to match the authToggle button via closest() so nested spans or icons work.
  document.body.addEventListener('click', (e) => {
    const btn = e.target.closest('#authToggle');
    if (btn) {
      const modal = document.getElementById('authModal');
      if (modal) modal.classList.remove('hidden');
    }
  });

  // Authentication UI event handlers
  const authToggle = document.getElementById('authToggle');
  const authModal = document.getElementById('authModal');
  const authClose = document.getElementById('authClose');
  const signupForm = document.getElementById('signupForm');
  const loginForm = document.getElementById('loginForm');
  authToggle?.addEventListener('click', () => {
    authModal?.classList.remove('hidden');
  });
  authClose?.addEventListener('click', () => {
    authModal?.classList.add('hidden');
    document.getElementById('authMessage').textContent = '';
  });
  signupForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('signupEmail').value.trim();
    const pwd = document.getElementById('signupPassword').value.trim();
    if (!email || !pwd) { toast('Please enter email and password.'); return; }
    document.getElementById('authMessage').textContent = 'Creating account...';
    try {
      const { user, error } = await supabaseSignup(email, pwd);
      if (error) throw error;
      document.getElementById('authMessage').textContent = 'Account created. Please log in.';
    } catch (err) {
      document.getElementById('authMessage').textContent = err?.message || 'Sign up failed.';
    }
  });
  loginForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value.trim();
    const pwd = document.getElementById('loginPassword').value.trim();
    if (!email || !pwd) { toast('Enter email and password.'); return; }
    document.getElementById('authMessage').textContent = 'Logging in...';
    try {
      const { user, access_token, error } = await supabaseLogin(email, pwd);
      if (error || !user) throw error || new Error('Login failed');
      currentUserId = user.id;
      // Use session access token for authenticated requests
      supabaseHeaders.Authorization = `Bearer ${access_token}`;
      await loadRemoteState();
      // Load user profile from Supabase and update state.profile. This must
      // happen after login so that currentUserId and supabaseHeaders are set.
      await loadUserProfile();
      authModal?.classList.add('hidden');
      document.getElementById('authMessage').textContent = '';
      toast('Logged in successfully');
      renderAll();
      // Prompt the user to pick subjects if they have not selected any yet.
      // If profile is incomplete (no exam session and zero weekly hours), show
      // the profile modal first. Otherwise prompt subject selection if no
      // subjects chosen yet.
      if (!state.profile?.exam_session && !(state.profile?.weekly_hours > 0)) {
        showProfileModal();
      } else if (!state.preferences?.subjects || state.preferences.subjects.length === 0) {
        showSubjectModal();
      }
    } catch (err) {
      document.getElementById('authMessage').textContent = err?.message || 'Login failed.';
    }
  });
}

function updateTimer() {
  const min = String(Math.floor(secondsLeft / 60)).padStart(2, '0');
  const sec = String(secondsLeft % 60).padStart(2, '0');
  $('#timerDisplay').textContent = `${min}:${sec}`;
}

// Wait for DOM to be ready before wiring events and rendering UI. Modules are deferred
// but using DOMContentLoaded ensures elements like the auth modal exist.
window.addEventListener('DOMContentLoaded', () => {
  populateSelects();
  wireEvents();
  // Initial render and timer setup when DOM is ready
  renderAll();
  updateTimer();
  // Initialize session length and break length from the input fields. This ensures
  // the timer display reflects any default values in the HTML and not just the
  // hard-coded 25:00. We set secondsLeft accordingly.
  const sessionInput = document.getElementById('sessionLength');
  const breakInput = document.getElementById('breakLength');
  if (sessionInput) {
    const v = parseInt(sessionInput.value, 10);
    if (!isNaN(v)) { sessionLength = v; secondsLeft = v * 60; }
  }
  if (breakInput) {
    const v = parseInt(breakInput.value, 10);
    if (!isNaN(v)) { breakLength = v; }
  }
  updateTimer();
});

// Show the subject selection modal and populate the form with checkboxes for each subject.
function showSubjectModal() {
  const modal = document.getElementById('subjectModal');
  const form = document.getElementById('subjectForm');
  if (!modal || !form) return;
  // Build checkbox list for all subjects. Use current preferences to check boxes.
  form.innerHTML = subjects.map(s => {
    const selected = state.preferences?.subjects?.includes(s.id);
    return `<label class="subject-option"><input type="checkbox" value="${s.id}" ${selected ? 'checked' : ''}> ${escapeHTML(s.name)} (${escapeHTML(s.level)})</label>`;
  }).join('');
  modal.classList.remove('hidden');
}

// Handle saving or cancelling of subject selection.
document.addEventListener('DOMContentLoaded', () => {
  const saveBtn = document.getElementById('subjectSave');
  const cancelBtn = document.getElementById('subjectCancel');
  saveBtn?.addEventListener('click', () => {
    const checks = document.querySelectorAll('#subjectForm input[type="checkbox"]');
    state.preferences.subjects = [...checks].filter(cb => cb.checked).map(cb => cb.value);
    // Save local state to persist subject preferences. The actual subject
    // selection is also persisted to the state table. A future enhancement
    // could insert records into the user_subjects table using Supabase,
    // mapping the subject slug to its numeric ID.
    saveState();
    renderAll();
    const modal = document.getElementById('subjectModal');
    modal?.classList.add('hidden');
  });
  cancelBtn?.addEventListener('click', () => {
    const modal = document.getElementById('subjectModal');
    modal?.classList.add('hidden');
  });

  // Profile modal save/cancel handlers
  const profileSaveBtn = document.getElementById('profileSave');
  const profileCancelBtn = document.getElementById('profileCancel');
  profileSaveBtn?.addEventListener('click', async () => {
    const examInput = document.getElementById('examSessionInput');
    const hoursInput = document.getElementById('weeklyHoursInput');
    const gradeInput = document.getElementById('targetGradeInput');
    const profile = {
      exam_session: examInput?.value.trim() || '',
      weekly_hours: parseInt(hoursInput?.value, 10) || 0,
      target_grade: parseInt(gradeInput?.value, 10) || 0
    };
    state.profile = profile;
    // Persist locally
    saveState();
    // Persist remotely
    await saveUserProfile(profile);
    const modal = document.getElementById('profileModal');
    modal?.classList.add('hidden');
    // After saving profile, if no subjects selected, prompt subject selection
    if (!state.preferences?.subjects || state.preferences.subjects.length === 0) {
      showSubjectModal();
    }
  });
  profileCancelBtn?.addEventListener('click', () => {
    const modal = document.getElementById('profileModal');
    modal?.classList.add('hidden');
  });
});

// Attempt to fetch the latest state from remote storage. If remote data is
// available, it will update the local state and re-render the UI. This call
// runs asynchronously and does not block the initial page load.
loadRemoteState();
