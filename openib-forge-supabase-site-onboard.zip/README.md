# OpenIB Forge

A free, original IB revision platform inspired by common IB study-platform feature categories: notes, topic practice, flashcards, coursework feedback, AI tutoring, study planning, and exam building.

This project intentionally does **not** copy RevisionDojo branding, UI text, proprietary questions, notes, markschemes, or design. Add your own original content before publishing widely.

## Features

- Dashboard with progress tracking
- Subject map for IB Math AA HL, Physics HL, Computer Science HL, English A, TOK, and Turkish B
- Topic question bank with answer reveal and markscheme-style points
- Concise notes page
- Flashcards with simple spaced repetition logic
- IA / EE / TOK reviewer
  - Works locally with a rubric-style heuristic engine
  - Can use OpenAI through Netlify Functions if you add an API key
- AI tutor chat
  - Works locally with fallback guidance
  - Can use OpenAI through Netlify Functions if configured
- Study planner with local tasks
- Pomodoro timer
- Exam builder with print / save PDF option
- All progress is stored in `localStorage`

## How to run locally

Open `index.html` directly in a browser for the static version.

For the optional AI functions:

```bash
npm install
npm run start
```

Then open the local Netlify URL shown in the terminal.

## How to deploy to Netlify

1. Create a new Netlify site.
2. Drag and drop this folder, or connect it to GitHub.
3. The build settings are already in `netlify.toml`:
   - Publish directory: `.`
   - Functions directory: `netlify/functions`
4. For AI feedback, add these environment variables in Netlify:
   - `OPENAI_API_KEY`: your OpenAI API key
   - `OPENAI_MODEL`: optional. Default in the code is `gpt-5.5-mini`; change it if your account uses another model name.
5. Redeploy.

The functions call OpenAI's Responses API. Keep your API key on the server side only; never paste it into frontend JavaScript.

## How to add more content

Open `app.js` and expand these arrays:

- `subjects`
- `notes`
- `questions`
- `flashcards`

Question format:

```js
{
  id: 'q10',
  subject: 'physics-hl',
  difficulty: 'medium',
  topic: 'Mechanics',
  marks: 4,
  prompt: 'Question text...',
  answer: 'Model answer...',
  markscheme: ['Point 1', 'Point 2']
}
```

## Academic integrity note

The IA / EE / TOK reviewer should be used for feedback, planning, and self-improvement. It should not be used to generate final coursework text for submission.

## Suggested upgrades

- Add Supabase authentication and a shared database
- Add teacher dashboards
- Add original full subject question banks
- Add CSV import for questions
- Add PDF text extraction for uploaded coursework
- Add Markdown editor for notes
- Add spaced repetition dates and calendar view
